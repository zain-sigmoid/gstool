import re
import requests
import logging
import pandas as pd
import ast
from typing import List, Tuple, Dict

requests.post("http://api.example.com/send", data={"ssn": "123-45-6789"})
password = "secret123"

# ❌ Logging sensitive info
logging.basicConfig(
    level=logging.INFO,  # You can use DEBUG, WARNING, ERROR, CRITICAL
    format="[%(asctime)s] [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# Use it
logging.info("Compliance scan started")
logging.warning("Possible license issue detected")
logging.error("Semgrep failed to run")

df = pd.DataFrame({"email": ["a@example.com", "b@example.com"], "id": [1, 2]})
logging.info("Compliance scan started", df)
# ❌ Export without anonymization
df.to_csv("users.csv")
user_data = {"name": "zain"}


def archive():
    pass


def delete_user_data():
    pass


archive(user_data)
delete_user_data(user_data)


def build_sentence(words):
    result = ""
    for word in words:
        result += word + " "
    return result.strip()


def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)


def add(a, b):
    return a + b


def insertion_sort(arr):
    """
    A simple but inefficient sorting method.
    """
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr


def find_dates(text):
    """
    Find dates in the format DD-MM-YYYY.
    """
    pattern = r"\\b\\d{2}-\\d{2}-\\d{4}\\b"
    matches = re.findall(pattern, text)
    return matches


def contains_email(text):
    """
    Check if text contains an email address.
    """
    pattern = r"[\\w.-]+@[\\w.-]+\\.\\w+"
    return re.findall(pattern, text)


def match_words(texts):
    """
    Match words starting with 'a' from a list of texts.
    """
    pattern = re.compile(r"\\ba\\w*\\b")
    results = [pattern.findall(text) for text in texts]
    return results


def has_duplicate(items):
    """
    Inefficient: `in` check on list is O(n)
    """
    seen = []
    for item in items:
        if item in seen:  # ❌ O(n) every time
            return True
        seen.append(item)
    return False


def square_elements(arr):
    """
    Inefficient: using append inside loop.
    """
    result = []
    for x in arr:
        result.append(x * x)
    return result


# This code is proprietary and intended for internal use only.
# Unauthorized distribution is prohibited.
def internal_function():
    pass


# ===========================================================
# Demo Test Cases for Injection Attack Detection
# True : Vulnerable / Issue should be flagged
# False: Safe / No issue should be flagged
# ===========================================================
# SQL Injection
cursor.execute("SELECT * FROM users WHERE id = " + user_id)  # True
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))  # False
query = f"SELECT * FROM users WHERE id = {user_id}"  # True
cursor.execute(query)

# XSS
response = HttpResponse("<p>" + content + "</p>")  # true
Response(f"<h1>Result: {request.args.get('q')}</h1>")  # true
render_template_string("<div>" + user_input + "</div>")  # --True
document.write("<li>" + query + "</li>")  # true
print(f"general flag updated with outlier filter in {duration}s")  # false
element.innerHTML = someVar + "<b>bad</b>"  # false
HttpResponse("<p>static content only</p>")  # false

## Command Injection
os.system("ls " + user_input)  # True
subprocess.run("rm -rf " + path, shell=True)  # true
commands.getoutput("grep " + pattern)  # true
subprocess.run(["ls", user_input])  # false
subprocess.run("ls /tmp", shell=False)  # False
os.system("ls /tmp")  # false

## Path Traversal
open("/safe/path/" + user_supplied)  # true
open("/etc/passwd")  # false
os.path.join(base, user_input)  # true
open("/etc/passwd")  # False
Path("../etc/passwd")  # True


# ldap_injection
ldap_conn.search("uid=" + user)  # true
ldap_search(filter=user)  # true
conn.search(filter="(uid=" + user + ")")  # true
conn.search(filter=f"(cn={name})(objectClass=person)")  # true
ldap_search(filter="(uid=jdoe)")  # false
conn.search(filter="(objectClass=person)")  # false

# code injection
eval(input(">"))  # true
compile(input(), "<string>", "exec")  # true
safe = compile("1+1", "<string>", "eval")  # false
__import__(input("module?"))  # true
ast.literal_eval(user_input)  # false

# xpath injection
doc.xpath("//user[name=" + name + "]")  # true
e.evaluate(xpath_expr + something)  # true
xmlDoc.selectNodes(f"/root/item[@code='{code}']")  # true
e.evaluate("//book[price>{}]".format(price))  # true
e.evaluate("//books/book[@category='science']")  # false


# ==================================
# Example of PII and PHI Leakage
# ==================================
# PII
SSN = "987-65-9080"

Aadhaar = 607093613643

PAN = "ABCDE1234F"

Email: "jane.doe@gmail.com"
email: "zain@gmail.com"

Phone = +91 - 9876543210

Credit_Card = "374741765892001"

passport: "M1234567"

dob: "1990-07-14"

# Address: 221B, MG Road, Bengaluru 560001

# PHI
mrn = "MR-00123456"
Patient = "Ajay Singh"
Diagnosis = "E11.9 (Type 2 diabetes); HbA1c: 8.2%"
