aws_access_key = "AKIAIOSFODNN7EXAMPL3"
aws_secret_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
githubToken = "ghp_1234567890abcdefghijklmnopqrstuvwx"
slack_webhook = (
    "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"
)
google_api_key = "AIzaSyAmhk91FhnUexAH3KU9_JP7zuUiP0P1Wow"
SERP_API = "f9b4316b25e6677e4a34765202635d8ffdbe74ac"
EXA_API = "7717b666-8b1d-4850-9999-6a0c45f3aec6"
TAVILY_API = "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"
twilioToken = "a3f8e5c9d1b7a3f4c9d1e3b8a9c2d3e1"
stripe_secret_key = "sk_test_4eC39HqLyjWDarjtT1zdp7dc"
StripePublishableKey = "pk_test_TYooMQauvdEDq54NiTphI7jx"
db_password = "P@ssw0rd123!"
private_rsa_key = """
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA1s7K+8pT8cE1gjm5eYFqvLTQo7r0Q9PlF5xMl49J39XKZNs3
Y+nxjO9O3o4WZuG+MzX/8b0tRkOjBVa6GKy78Hwnz0YrCgFJ3h3BZ6VHoHBozUCu
-----END RSA PRIVATE KEY-----
"""
fb_app_secret = "1a2b3c4d5e6f7g8h9i0j"
JWTSecret = "1ehg7ujkom7fg5tybvg"
heroku_api_key = "12345678-90ab-cdef-1234-567890abcdef"
dockerhub_password = "Alpha@docker123"
mongo_uri = "mongodb+srv://user:password@cluster.mongodb.net/test"
shopify_api_key = "shpat_abcdef1234567890abcdef1234567890"
UserName = "admin"
UserPassword = "admin1234"
USERNAME = "zain"
user = "john.doe"
login = "demo_user"
date_of_birth = "10/08/1990"
