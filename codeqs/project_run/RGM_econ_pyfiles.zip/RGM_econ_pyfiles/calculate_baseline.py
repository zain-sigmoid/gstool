# %% [markdown]
# ### Path: src/models/baseline_module.py

# %% [markdown]
#     """
#     Calculates and imputes the baselines
#     Args:
#         raw_loess_all : all data containing good and dropped pairs
#         data_for_modeling: data used for modeling - contains the loess trend
#         final_results: final consolidated and imputed modeling results
#         s1_res: full modeling results from s1 model
#         s2_res: full modeling results from s2 model
#         u1_res: full modeling results from u1 model
#         u2_res: full modeling results from u2 model
#         params: dictionary of parameters configured by user
#         catalog: dictionary with files catalog
#     Returns:
#         imputed_baseline: data with baselines calculated
#     """

# %% [markdown]
# This function is called at the line 158 of the code as:\
# calculate_baseline(\
#             raw_loess_all,\
#             base_loess,\
#             consolidated_results,\
#             s1_res,\
#             s2_res,\
#             u1_res,\
#             u2_res,\
#             params,\
#             catalog,\
#         )

# %%
# Function calculate_baseline:
# def calculate_baseline(
#     raw_loess_all: pd.DataFrame,
#     data_for_modeling: pd.DataFrame,
#     final_results: pd.DataFrame,
#     s1_res: pd.DataFrame,
#     s2_res: pd.DataFrame,
#     u1_res: pd.DataFrame,
#     u2_res: pd.DataFrame,
#     params: dict,
#     catalog: dict,
# ) -> pd.DataFrame:

# %% [markdown]
# # Importing libraries

# %%
from functools import reduce
import numpy as np
import pandas as pd
import re

# %%
import bios
import os

# %% [markdown]
# # Function to load all parameters in yml format

# %%
### Path to this function: src/utils/config.py
def load_params(base: str):
    """
    Function to load parameters file in yml format into the environment
    Args:
        base : base location to project where the notebooks and parameters folders are present
    Returns:
        final_params: Dictionary of all parameter files present within the parameters folder ending with .yml
    """
    final_params = {}
    parameters_list = os.listdir(base + "/parameters")
    parameters_list = [i for i in parameters_list if i.endswith("yml")]
    for params in parameters_list:

        my_dict = bios.read(base + "/parameters/" + params)

        final_params.update(my_dict)

    return final_params

# %%
base_dir = os.getcwd()
params = load_params(base_dir)
### params will have all the parameters files which are in the parameters folder

# %% [markdown]
# # Load the input files

# %%
raw_loess_all = pd.read_csv("./01_intermediate_outputs/own/rgm_econ_all_data.csv")
data_for_modeling = pd.read_csv("./04_model_results/loess/own/loess_prediction.csv")
final_results = pd.read_csv("./05_model_post_processing/own/decayed_consolidated_results_pl3.csv")

s1_res = pd.read_csv("./01_intermediate_outputs/own/sams-club/full_model_results_struct_without_cpi.csv")
s2_res = pd.read_csv("./01_intermediate_outputs/own/sams-club/full_model_results_struct_with_cpi.csv")
u1_res = pd.read_csv("./01_intermediate_outputs/own/sams-club/full_model_results_unstruct_without_cpi.csv")
u2_res = pd.read_csv("./01_intermediate_outputs/own/sams-club/full_model_results_unstruct_with_cpi.csv")

# %%
## checking with original files
final_results_og = pd.read_csv('./05_model_post_processing/decayed_consolidated_results_pl3.csv')
s1_res_og = pd.read_csv("./04_model_results/model_results/full_model_results_struct_with_cpi.csv")
s2_res_og = pd.read_csv("./04_model_results/model_results/full_model_results_struct_with_cpi.csv")
u1_res_og = pd.read_csv("./04_model_results/model_results/full_model_results_unstruct_without_cpi.csv")
u2_res_og = pd.read_csv("./04_model_results/model_results/full_model_results_unstruct_with_cpi.csv")

# %%
def printShape(*array):
    for x in array:
        print(x.shape)

def printByLine(df):
    if len(df) == 0:
        return 0
    for x in df:
        print(x)

# %%
from termcolor import colored

# %%
final_results_og = final_results_og[final_results_og['retailer_id'].isin(['SAMS CLUB'])]
s1_res_og = s1_res_og[s1_res_og['retailer_id'].isin(['SAMS CLUB'])]
s2_res_og = s2_res_og[s2_res_og['retailer_id'].isin(['SAMS CLUB'])]
u1_res_og = u1_res_og[u1_res_og['retailer_id'].isin(['SAMS CLUB'])]
u2_res_og = u2_res_og[u2_res_og['retailer_id'].isin(['SAMS CLUB'])]
print(colored('Original files','yellow'))
printShape(final_results_og,s1_res_og,s2_res_og,u1_res_og,u2_res_og)

print(colored('our files','yellow'))
printShape(final_results_og,s1_res_og,s2_res_og,u1_res_og,u2_res_og)

# %%
raw_loess_all_f = raw_loess_all[raw_loess_all['retailer_id'].isin(['SAMS CLUB'])]
data_for_modeling_f = data_for_modeling[data_for_modeling['retailer_id'].isin(['SAMS CLUB'])]

# %% [markdown]
# # Start of calculate_baseline

# %% [markdown]
# ## Helper functions

# %% [markdown]
# ### Function to load the function from the notebook

# %%
### Path to the function: src/utils/utils.py
def load_func(dotpath: str):
    """
    Helper function to load a function in the current notebook and return a function for later execution.
    Function is right-most segment.
    Args:
        dotpath: function path (ignored)
    Returns:
        Function that accepts arguments and calls the loaded function.
    """
    func_name = dotpath.split(".")[-1]
    func = globals().get(func_name)
    if func is None:
        raise ValueError(f"Function '{func_name}' not found in the global namespace.")
    if not callable(func):
        raise ValueError(f"'{func_name}' is not callable.")
    
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    
    return wrapper

# %% [markdown]
# ### Function to create columns for pantry loading features

# %%
### Path to the function: src/utils/utils.py
def pantry_loading_func(num_pl_features):
    """
    Helper function to create colnames for pantry loading features
    Args:
        num_pl_features: int
            Number of pantry loading features
    Returns:
        pl_features_names: str
            List of pantry loading features names
    """
    pl_features_names = [f"pl{i}" for i in range(1, num_pl_features + 1)]
    return pl_features_names

# %% [markdown]
# ### Function to append "log_" to the volume column name

# %%
### Path to the function: src/utils/utils.py
def log_volume(vol_col: str) -> str:
    """
    Helper function to append "log_" to the volume column name
    Args:
        vol_col: string column name of column containing volume info
    Returns:
        string column name with "log_" appended
    """
    return f"log_{vol_col}"

# %% [markdown]
# ## Function to prepare the data for baseline calculation and imputation

# %%
def data_for_baseline(
    raw_loess_all: pd.DataFrame, data_for_modeling: pd.DataFrame, params: dict
) -> pd.DataFrame:
    """
    Prepares the data for baseline imputation.
    Applies the trend observed in good pairs to all pairs (including dropped pairs)
    Args:
        raw_loess_all : all data containing good and dropped pairs
        data_for_modeling: data used for modeling - contains the trend in good pairs
        params: dictionary of parameters configured by user
    Returns:
        raw_loess_all: all data containing imputed trend
    """

    print("Starting data prep for baseline module")

    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    granularity = params["ewb"]["data_management"]["granularity"]
    week_number = params["ewb"]["data_management"]["granularity"] + "_number"
    column_with_date = params["ewb"]["data_management"]["column_with_date"]

    # Get trend from modelled pairs
    trend_good_pairs = data_for_modeling[
        list(
            filter(
                None, [level_1] + [level_2] + [level_3] + [f"year_{granularity}"] + ["trend_term"]
            )
        )
    ]

    # Merge the trend into the raw_loess_all for good pairs

    # Convert to year_week or year_month to character to perform the join
    trend_good_pairs[f"year_{granularity}"] = trend_good_pairs[f"year_{granularity}"].apply(str)
    raw_loess_all[f"year_{granularity}"] = raw_loess_all[f"year_{granularity}"].apply(str)

    raw_loess_all = raw_loess_all.merge(
        trend_good_pairs,
        on=list(filter(None, [level_1] + [level_2] + [level_3] + [f"year_{granularity}"])),
        how="left",
    )

    # Imputation of trend -----------------------------------------------------
    #     grouping_cols = list(filter(None, [level_1, level_2, level_3]))
    #     raw_loess_all = raw_loess_all.sort_values(by = grouping_cols + [column_with_date], ascending = True)
    #     raw_loess_all[f"continuous_{granularity}"] = raw_loess_all.groupby(by = grouping_cols).cumcount()+1

    raw_loess_all["trend_term"] = np.where(
        raw_loess_all["trend_term"].isna(),
        raw_loess_all[week_number].astype("float64") / 100.0,
        raw_loess_all["trend_term"],
    )
    raw_loess_all["trend_term"] = raw_loess_all["trend_term"].astype("float64")

    raw_loess_all["resid"] = 0
    print("Finished data prep for baseline module")

    return raw_loess_all

# %% [markdown]
# ## Function to merge the imputed trends baseline with the final model results 

# %%
def merge_baseline(
    baseline_data: pd.DataFrame, final_results: pd.DataFrame, params: dict
) -> pd.DataFrame:
    """
    Merges the imputed trends baseline with the final model results
    Args:
        baseline_data : all data containing good and dropped pairs with imputed trend
        final_results: final modeling results
        params: dictionary of parameters configured by user
    Returns:
        df: all data containing imputed trend merged with model results
    """
    print("Merging imputed trends baseline with final model results")
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

    # Keeping only the coefficients
    non_coeff_cols = (
        set(final_results.columns).intersection(set(baseline_data.columns))
    ).difference(set(grouping_columns))

    df = baseline_data.merge(
        final_results.drop(columns=non_coeff_cols), how="left", on=grouping_columns
    )
    # removing all irrelevant columns to save memory
    df.drop(
        columns=df.columns[df.columns.str.match(f"^[(S1)|(S2)|(U1)|(U2)]|(.*_impute_flag)")],
        inplace=True,
    )

    print("Finished merging imputed trends baseline with final model results")

    return df

# %% [markdown]
# ## Function to create the effect term in the dataframe

# %%
def create_effect_terms(df: pd.DataFrame, params: dict) -> pd.DataFrame:
    """
    Creates the effect terms
    Args:
        df : all data (good+dropped pairs) along with modeling results
        params: dictionary of parameters configured by user
    Returns:
        df: all data with added effect term columns
    """
    print("Creating effect terms for baseline")
    # start_covid_period = params["holidays_config"]["covid_flags"]["start_covid_period"]
    promo_agg = params["ewb"]["modeling"]["baseline_module"]["promo_agg"]
    promo_agg_vars = params["ewb"]["modeling"]["baseline_module"]["promo_agg_vars"]
    promo_no_agg_vars = params["ewb"]["modeling"]["baseline_module"]["promo_no_agg_vars"]
    distribution = params["ewb"]["modeling"]["mixed_models"]["distribution"]
    pantry_flags = params["ewb"]["data_management"]["pantry_flags"]
    pl_vars = pantry_loading_func(pantry_flags)
    opi_grouping = params["ewb"]["data_management"]["opi_grouping"]
    granularity = params["ewb"]["data_management"]["granularity"]
    promo_acv_vars = params["ewb"]["data_management"]["acv_vars_list"]

    ######################## Getting the top-down baseline
    ##### Necessary terms:

    # zero out incorrect signs of elasticity and promo coefficients
    #if not df["pre_covid_elasticity"].dropna().empty:
    #    df["real_elasticity"] = np.where(
    #        df[f"year_{granularity}"].astype(int) <= start_covid_period,
    #        df["pre_covid_elasticity"],
    #        df["elasticity"],
    #    )
    #else:
    #    df["real_elasticity"] = df["elasticity"]
    
    df["real_elasticity"] = df["elasticity"]

    df["price_effect_term"] = np.where(
        (df["price"] > 0) & (df["edlp_price"] > 0),
        df["real_elasticity"] * np.log(df["price"] / df["edlp_price"]),
        0.0,
    )

    opi_vars = list(df.columns[df.columns.str.match(f"^[fr]e_(.*)opi")])
    if opi_vars:
        df["opi_effect_term"] = np.where(
            (df["edlp_opi"] > 0) & (df["opi"] > 0),
            np.log(df["opi"] / df["edlp_opi"]) * df[opi_vars[0]],
            0,
        )
    else:
        df["opi_effect_term"] = 0
    df["error_effect_term"] = df["resid"]

    if promo_agg:
        # calculation _effect_terms for promo_agg = TRUE see vars in config
        promo_agg_vars = [s.replace("log_", "") for s in promo_agg_vars]
        promo_agg_vars_effect = [
            y
            for sublist in list(
                [
                    list(df.columns[df.columns.str.match(f"^([fr]e_)+(.+){x}")])
                    for x in promo_agg_vars
                ]
            )
            for y in sublist
        ]
        # getting just promo_agg_vars that have effects
        promo_agg_vars = [re.sub("^([fr]e_)*", "", s) for s in promo_agg_vars_effect]
        if promo_agg_vars_effect:
            df["promo_effect_term"] = (
                df[promo_agg_vars_effect].mul(df[promo_agg_vars].values).sum(1, skipna=False)
            )
        else:
            df["promo_effect_term"] = 0
    else:
        # calculation _effect_terms for promo_agg = FALSE see vars in config

        promo_effect_vars = [
            y
            for sublist in list(
                [
                    list(df.columns[df.columns.str.match(f"^[fr]e_{x}")])
                    for x in promo_acv_vars  # promo_no_agg_vars previously
                ]
            )
            for y in sublist
        ]
        # getting just promo_vars that have effects
        # promo_vars = [re.sub("^[fr]e_", "", s) for s in promo_effect_vars]
        promo_vars = promo_acv_vars

        if promo_vars:
            df["promo_effect_term"] = (
                df[promo_effect_vars].mul(df[promo_vars].values).sum(1, skipna=False)
            )
        else:
            df["promo_effect_term"] = 0

        df["add_acv_term"] = np.where(
            (df["log_acv_diff"] > 0) & (df["promo_flag"] == 1),
            df["log_acv_diff"]
            * df[list(df.columns[df.columns.str.match(f"^[fr]e_{distribution}")])[0]],
            0,
        )

        pl_effect_vars = [
            y
            for sublist in list(
                [list(df.columns[df.columns.str.match(f"^[fr]e_{x}")]) for x in pl_vars]
            )
            for y in sublist
        ]
        # getting just pantry loading variables that have effects
        pl_vars = [re.sub("^[fr]e_", "", s) for s in pl_effect_vars]

        if pl_vars:
            df["pl_effect_term"] = df[pl_effect_vars].mul(df[pl_vars].values).sum(1, skipna=False)

        df["opi_promo_flag"] = np.where(
            df.groupby(opi_grouping)["promo_flag"].transform("sum") - df["promo_flag"] > 1, 1, 0
        )
        df["promo_effect_term"] = np.where(
            (df["promo_effect_term"] > 0) & (df["promo_flag"] == 1), df["promo_effect_term"], 0
        )
        _outlier_retailers = params["ewb"]["data_management"]["outlier_retailers"]
        df.loc[df["retailer_id"].isin(_outlier_retailers),"promo_effect_term"] = df["promo_flag_outlier_retailers"] * df["re_promo_flag_outlier_retailers"]
        df["opi_effect_term"] = np.where(
            (df["opi_promo_flag"] == 1) & (df["promo_flag"] == 0), df["opi_effect_term"], 0
        )
        print("Finished creating effect terms for baseline")
        return df

# %% [markdown]
# ## Function to create decomposition terms

# %%
from termcolor import colored

# %%
hol_all=[]
for holiday in params["holidays_config"]["holidays"]:
    if "WALMART" in holiday.get("filter_values", []):
        hol_all.append(holiday["name"])

print(hol_all)

# %%
def create_decomp_terms(df, params: dict):
    """
    Creates the decomposition terms
    Args:
        df : all data (good+dropped pairs) along with modeling results and effect terms
        params: dictionary of parameters configured by user
    Returns:
        df: all data with added decomposition term columns
    """

    print("Creating decomposition terms for baseline")

    promo_distribution = params["ewb"]["modeling"]["baseline_module"]["promo_distribution"]
    distribution = params["ewb"]["modeling"]["mixed_models"]["distribution"]
    promo_agg = params["ewb"]["modeling"]["baseline_module"]["promo_agg"]
    promo_agg_vars = params["ewb"]["modeling"]["baseline_module"]["promo_agg_vars"]
    promo_no_agg_vars = params["ewb"]["modeling"]["baseline_module"]["promo_no_agg_vars"]
    price_term = params["ewb"]["modeling"]["common"]["price_term"]
    # covid_factor = params["ewb"]["modeling"]["common"]["covid_factor"]
    pantry_flags = params["ewb"]["data_management"]["pantry_flags"]
    pl_vars = pantry_loading_func(pantry_flags)
    items = params["ewb"]["data_management"]["items"]
    promo_acv_vars = params["ewb"]["data_management"]["acv_vars_list"]
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

    ############### DECOMPOSITION (DECOMP)directly incorporated into baseline module ###########################

    ### CALCULATION ALL d_*_term ####

    #### calculation d_terms for competitors indexes ####
    # take all log vars with competitors indexes: cpi, opi, xpi
    oxpi_vars_effect = list(df.columns[df.columns.str.match(f"^[fr]e_log_(.?)pi")])
    oxpi_vars = [re.sub("^[fr]e_", "", s) for s in oxpi_vars_effect]

    for level in grouping_columns:
        oxpi_vars = [i.replace("_" + level, "") for i in oxpi_vars]

    # calculate all d_log_opi(xpi|cpi)_term IF ANY affects for them existed
    if oxpi_vars_effect:
        d_oxpi_cols = ["d_" + sub.replace("log_", "") + "_term" for sub in oxpi_vars]
        df[d_oxpi_cols] = df[oxpi_vars_effect].mul(df[oxpi_vars].values)

    #### calculation d_*_terms for promo_distribution indexes: acv_* ####
    # getting effects (re|fe)  IF ANY by promo_distribution
    if promo_agg:
        # calculation _effect_terms for promo_agg = TRUE see vars in config
        # promo_agg_vars = [s.replace("log_", "") for s in promo_agg_vars]
        promo_agg_vars_effect = [
            y
            for sublist in list(
                [
                    list(df.columns[df.columns.str.match(f"^([fr]e_)+(.+){x}")])
                    for x in promo_agg_vars
                ]
            )
            for y in sublist
        ]
        # getting just promo_agg_vars that have effects
        promo_agg_vars = [re.sub("^([fr]e_)*", "", s) for s in promo_agg_vars_effect]

        if promo_agg_vars_effect:
            df["d_promo_term"] = (
                df[promo_agg_vars_effect].mul(df[promo_agg_vars].values).sum(1, skipna=False)
            )
        else:
            df["d_promo_term"] = 0
    else:
        # calculation _effect_terms for promo_agg = FALSE see vars in config

        promo_effect_vars = [
            y
            for sublist in list(
                [list(df.columns[df.columns.str.match(f"^[fr]e_{x}")]) for x in promo_acv_vars]
            )
            for y in sublist
        ]
        # getting just promo_vars that have effects
        # promo_vars = [re.sub("^[fr]e_", "", s) for s in promo_effect_vars]
        promo_vars = promo_acv_vars

        if promo_vars:
            df["d_promo_term"] = (
                df[promo_effect_vars].mul(df[promo_vars].values).sum(1, skipna=False)
            )
        else:
            df["d_promo_term"] = 0

    #### calculation d_*_terms for pantry_loading: pl_* ####
    pl_effect_vars = [
        y
        for sublist in list(
            [list(df.columns[df.columns.str.match(f"^[fr]e_{x}")]) for x in pl_vars]
        )
        for y in sublist
    ]
    # getting just pantry loading variables that have effects
    pl_vars = [re.sub("^[fr]e_", "", s) for s in pl_effect_vars]

    if pl_vars:
        df["d_pl_term"] = df[pl_effect_vars].mul(df[pl_vars].values).sum(1, skipna=False)

    #### calculation d_*_terms for misc coeff ####
    df["d_intercept"] = df[df.columns[df.columns.str.match("^([fr]e_)*intercept$")]]
    df["d_trend"] = (
        df[df.columns[df.columns.str.match("^([fr]e_)trend")]].iloc[:, 0] * df["trend_term"]
    )
    df["d_acv_term"] = (
        df[distribution] * df[df.columns[df.columns.str.match(f"^[fr]e_{distribution}")]].iloc[:, 0]
    )
    df["d_price_term"] = df["real_elasticity"] * df[price_term]
 #   if items:
 #       df["d_avg_items_term"] = (
 #           df["log_avg_items"]
 #           * df[df.columns[df.columns.str.match("^[fr]e_(.)*avg_items")]].iloc[:, 0]
 #       )

    #### calculation d_*_terms for seasonality
    # each row get the value of the effect term corresponding to the month of that row. E.g. if month=OCT, then d_seasonal_term = fe_month_OCT
    df["month"] = df["month"].astype(int)
    df["month"] = df.month.map("{:02}".format)

    if "fe_month01_" + level_2 in df.columns:
        get_month_column = (
            lambda row: row["fe_month" + row["month"] + "_" + level_2]
            if "fe_month" + row["month"] + "_" + level_2 in row.index
            else row["re_month_" + row["month"]]
        )
    elif "fe_month01_" + level_1 in df.columns:
        get_month_column = (
            lambda row: row["fe_month" + row["month"] + "_" + level_1]
            if "fe_month" + row["month"] + "_" + level_1 in row.index
            else row["re_month_" + row["month"]]
        )
    else:
        get_month_column = (
            lambda row: row["fe_month_" + row["month"]]
            if "fe_month_" + row["month"] in row.index
            else row["re_month_" + row["month"]]
        )

    df["month"] = df["month"].astype(str)
    df["d_seasonal_term"] = df.apply(get_month_column, axis=1)

    # df["d_seasonal_term"] = df[df.columns[df.columns.str.match("^([fr]e_)*month_{}")]]


    ################################# Covid Removed ############################
    # # getting vars for covid_flags_N
    # covid_flags = list(df.columns[df.columns.str.match("^covid_flag_[0-9]")])
    # # getting IF ANY effects for covid_flags_N. NB "_" is optional in effect colnames
    # covid_flags_effect = [
    #     y
    #     for sublist in list(
    #         [
    #             list(df.columns[df.columns.str.match(f"^[fr]e_covid_flag(_)*{x[-1]}")])
    #             for x in covid_flags
    #         ]
    #     )
    #     for y in sublist
    # ]
    ################################# ############## ############################


    # exclude covid_flags if effects for them is not existed
    # covid_flags = [re.sub("^([fr]e_)*", "", s) for s in covid_flags_effect]


    ################################# Covid Removed ############################
    # if df.columns.str.match("(.)*covid_price_effect(.)*").any() and covid_flags_effect:
    #     df["d_covid_intercept"] = (
    #         df[df.columns[df.columns.str.match("(.)*covid_price_effect(.)*")]].iloc[:, 0]
    #         * df[covid_factor]
    #     ) + (df[covid_flags].mul(df[covid_flags_effect].values).sum(1, skipna=False))
    ################################# ################# ############################

    # get list of holidays from colnames
    # holidays = list(df.columns[df.columns.str.match("^hol_")])
    hol_all = []
    #changee for sams club
    # for holiday in params["holidays_config"]["holidays"]:
    #     hol_all.append(holiday["name"])
    for holiday in params["holidays_config"]["holidays"]:
        if "SAMS CLUB" in holiday.get("filter_values", []):
            hol_all.append(holiday["name"])

    
    print(colored('holiday all','yellow'),'\n',len(hol_all))
    printByLine(hol_all)
    # getting effects for holidays if ANY
    # holidays_effect = list(df.columns[df.columns.str.match("^[fr]e_hol_")])
    holidays_effect = [
        y
        for sublist in list(
            [list(df.columns[df.columns.str.match(f"^[fr]e_{x}")]) for x in hol_all]
        )
        for y in sublist
    ]
    print(colored('holidays_effect: ','yellow'),'\n',len(holidays_effect))
    printByLine(holidays_effect)
    # find holidays which have effects
    # holidays = [re.sub("^([fr]e_)*", "", s) for s in holidays_effect]
    holidays = [hol for hol in hol_all if hol in df.columns]
    print(colored('holidays','yellow'),'\n',len(holidays))
    printByLine(holidays)
    if holidays_effect:
        df["d_holiday_term"] = df[holidays_effect].mul(df[holidays].values).sum(1, skipna=False)

    print("Finished creating decomposition terms for baseline")
    return df

# %% [markdown]
# ## Function to calculate error term

# %%
def calculate_error_term(
    df: pd.DataFrame,
    s1_res: pd.DataFrame,
    s2_res: pd.DataFrame,
    u1_res: pd.DataFrame,
    u2_res: pd.DataFrame,
    params: dict,
) -> pd.DataFrame:
    """
    Calculates predicted volume...
    Args:
        df : all data containing good and dropped pairs with imputed trend
        s1_res: full modeling results from s1 model
        s2_res: full modeling results from s2 model
        u1_res: full modeling results from u1 model
        u2_res: full modeling results from u2 model
        params: dictionary of parameters configured by user
    Returns:
        baseline_data: baseline data with calculated predicted volume
    """
    granularity = params["ewb"]["data_management"]["granularity"]
    log_volume = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
        params["ewb"]["data_management"]["volume"]
    )
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

    # calculating error term for good pairs
    s1_res = s1_res[["predicted_vol", "pair", f"year_{granularity}"]]
    s2_res = s2_res[["predicted_vol", "pair", f"year_{granularity}"]]
    u1_res = u1_res[["predicted_vol", "pair", f"year_{granularity}"]]
    u2_res = u2_res[["predicted_vol", "pair", f"year_{granularity}"]]
    s1_res = s1_res.rename(columns={"predicted_vol": "predicted_vol_S1"})
    s2_res = s2_res.rename(columns={"predicted_vol": "predicted_vol_S2"})
    u1_res = u1_res.rename(columns={"predicted_vol": "predicted_vol_U1"})
    u2_res = u2_res.rename(columns={"predicted_vol": "predicted_vol_U2"})

    df[f"year_{granularity}"] = df[f"year_{granularity}"].astype("int64")
    dfs = [s1_res, s2_res, u1_res, u2_res, df]
    #reduce is used to merge all the dfs iteratively.
    df_merged = reduce(
        lambda left, right: pd.merge(left, right, on=["pair", f"year_{granularity}"], how="outer"),
        dfs,
    )

    condlist = [
        df_merged["which_model"] == "S1",
        df_merged["which_model"] == "S2",
        df_merged["which_model"] == "U1",
        df_merged["which_model"] == "U2",
    ]
    choicelist = [
        df_merged["predicted_vol_S1"],
        df_merged["predicted_vol_S2"],
        df_merged["predicted_vol_U1"],
        df_merged["predicted_vol_U2"],
    ]

    df_merged["predicted_vol_1"] = np.select(condlist, choicelist, np.nan)
    df_merged["predicted_vol_1"] = np.log(df_merged["predicted_vol_1"])
    df_merged["error_term_good_pairs"] = df_merged[log_volume] - df_merged["predicted_vol_1"]
    df_merged["error_term_good_pairs"] = np.where(
        (df_merged["promo_flag"] == 1) & (df_merged["promo_effect_term"] > 0),
        df_merged["error_term_good_pairs"],
        0,
    )

    # updating a flag
    df_merged["general_flag"] = np.where(
        (df_merged["which_model"].isna()) & (df_merged["general_flag"] == "GOOD"),
        "DROP: Non robust results",
        df_merged["general_flag"],
    )

    # calculating error effect for imputed pairs
    #### aggregation all d_terms calculated above in consolidated error: error_effect_term_consolid ####
    df_merged["consolid_pred"] = df_merged[
        df_merged.columns[df_merged.columns.str.match("^d_.*?term|^d_.*?intercept|^d_.*?trend")]
    ].sum(1, skipna=False)
    df_merged["consolid_resid"] = df_merged[log_volume] - df_merged["consolid_pred"]
    df_merged["avg_resid"] = df_merged.groupby(grouping_columns)["consolid_resid"].transform("mean")
    df_merged["cntrd_resid"] = df_merged["consolid_resid"] - df_merged["avg_resid"]
    df_merged["error_effect_term_consolid"] = np.where(
        (df_merged["promo_flag"] == 1) & (df_merged["promo_effect_term"] > 0),
        df_merged["cntrd_resid"],
        0,
    )

    df_merged["error_effect_term"] = np.where(
        df_merged["general_flag"] == "GOOD",
        df_merged["error_term_good_pairs"],
        df_merged["error_effect_term_consolid"],
    )
    df_merged["error_effect_term"] = np.where((df_merged["promo_flag"] == 1) & (df_merged["error_effect_term"] < 0),0,df_merged["error_effect_term"])
    return df_merged

# %% [markdown]
# ## Function to calculate final baseline coeffs using effect and decomposition terms

# %%
def create_final_baseline_coef(df: pd.DataFrame, params: dict) -> pd.DataFrame:
    """
    Calculates final baseline coeffs using effect and decomposition terms
    Args:
        df : all data (good+dropped pairs) along with effect and decomposition terms
        params: dictionary of parameters configured by user
    Returns:
        df: all data with added final baseline coeffs
    """
    print("Calculating final baseline coeffs")
    target = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
        params["ewb"]["data_management"]["volume"]
    )
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

    #### calculation final baseline coeffs by errors ####

    df["base_td_no_opi"] = np.exp(
        df.eval(
            target
            + " - "
            + (" - ").join(list(df.columns[df.columns.str.match(f"^(?!.*pi)(?=.*effect_term$)")]))
        )
    )
    df["base_td"] = np.exp(
        df.eval(
            target + " - " + (" - ").join(list(df.columns[df.columns.str.match(f".*effect_term$")]))
        )
    )
    df["base_td_no_opi_cons_error"] = np.exp(
        df.eval(
            target
            + " - "
            + (" - ").join(
                list(
                    df.columns[
                        df.columns.str.match(f"^(?!.*pi)(?=.*effect_term)(?!error(.*?)term$)")
                    ]
                )
            )
        )
    )
    df["base_td_cons_error"] = np.exp(
        df.eval(
            target
            + " - "
            + (" - ").join(
                list(df.columns[df.columns.str.match(f"^(?=.*effect_term)(?!error(.*?)term$)")])
            )
        )
    )

    print("Finished calculating final baseline coeffs")
    return df

# %% [markdown]
# ## Function to impute the bad baseline coeffs

# %%
def impute_bad_baseline(df: pd.DataFrame, params: dict) -> pd.DataFrame:
    """
    Imputes the bad baseline coeffs
    Args:
        df : all data (good+dropped pairs) along with final baseline coeffs
        params: dictionary of parameters configured by user
    Returns:
        df: all data with bad baseline coeffs imputed
    """

    print("Imputing the bad baseline coeffs")
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))
    volume = params["ewb"]["data_management"]["volume"]
    holidays = params["ewb"]["modeling"]["baseline_module"]["holidays"]
    baseline_selected = params["ewb"]["modeling"]["baseline_module"]["baseline_selected"]
    roll_window = params["ewb"]["modeling"]["baseline_module"]["roll_window"]

    hol_absent_in_df = [hol for hol in holidays if hol not in df.columns]
    
    try:
         df["holiday_col"] = df[holidays].sum(axis=1)
    except:
        raise Exception('Following holiday(s) is(are) in list which is(are) not in dataframe', hol_absent_in_df)
    
    df["holiday_col"] = df[holidays].sum(axis=1)
    ### First Logic for baseline detection
    baseline = df.copy()

    ### Second Logic for baseline detection
    baseline["EWB_base_logic2"] = np.where(
        (baseline[volume].notna() | baseline[volume] != 0) & (baseline[baseline_selected] == 0),
        1,
        0,
    )

    # Promo week effect -lags of lift
    baseline["promo_1_week_prev"] = (
        baseline.groupby(grouping_columns)["promo_flag"].shift(1).fillna(0)
    )
    baseline["promo_2_week_prev"] = (
        baseline.groupby(grouping_columns)["promo_flag"].shift(2).fillna(0)
    )
    baseline["promo_3_week_prev"] = (
        baseline.groupby(grouping_columns)["promo_flag"].shift(3).fillna(0)
    )
    promo_lag_cols = list(baseline.columns[baseline.columns.str.match("(.)*prev$")])
    baseline["promo_last_3_wks"] = np.where(baseline[promo_lag_cols].sum(axis=1) > 0, 1, 0)
    baseline.drop(columns=promo_lag_cols, inplace=True)

    ### Third Logic for baseline detection
    # TODO: test
    baseline["EWB_base_logic3a"] = np.where(
        baseline[baseline_selected] / baseline[volume] > 1.5, 1, 0
    )
    baseline["EWB_base_logic3c"] = np.where(
        (baseline[baseline_selected] > baseline[volume]) & (baseline["promo_last_3_wks"] == 0), 1, 0
    )
    baseline["EWB_base_logic3"] = np.where(
        (baseline["EWB_base_logic3a"] == 1) | (baseline["EWB_base_logic3c"] == 1), 1, 0
    )

    ### Fourth Logic for baseline detection
    baseline["EWB_base_logic4"] = np.where(
        (baseline["promo_flag"] == 1)
        & (
            baseline[baseline_selected]
            < baseline.groupby(grouping_columns)[baseline_selected].shift(1).fillna(0)
        )
        & (
            baseline[baseline_selected]
            < baseline.groupby(grouping_columns)[baseline_selected].shift(-1).fillna(0)
        ),
        1,
        0,
    )
    baseline[["EWB_base_logic4"]] = baseline[["EWB_base_logic4"]].fillna(0)

    baseline["EWB_base_logic5"] = np.where(
        (baseline["promo_flag"] == 1)
        & (baseline["holiday_col"] == 0
        )
        & (
            baseline[baseline_selected]
            > baseline.groupby(grouping_columns)[baseline_selected].shift(1).fillna(0)
        )
        & (
            baseline[baseline_selected]
            > baseline.groupby(grouping_columns)[baseline_selected].shift(-1).fillna(0)
        ),
        1,
        0,
    )
    baseline[["EWB_base_logic5"]] = baseline[["EWB_base_logic5"]].fillna(0)
    
    baseline["EWB_base_logic6"] = np.where(
        (baseline["promo_flag"] == 1
        )
        & ((
            baseline[baseline_selected]
            < 0.75*baseline.groupby(grouping_columns)[baseline_selected].shift(1).fillna(0)
        )
        | (
            baseline[baseline_selected]
            < 0.75*baseline.groupby(grouping_columns)[baseline_selected].shift(-1).fillna(0)
        )),
        1,
        0,
    )
    baseline[["EWB_base_logic6"]] = baseline[["EWB_base_logic6"]].fillna(0)

    ### Finding bad baselines
    baseline["EWB_bad_flag"] = np.where(
        (baseline["EWB_base_logic2"] + baseline["EWB_base_logic3"] + baseline["EWB_base_logic4"] + baseline["EWB_base_logic5"] + baseline["EWB_base_logic6"])
        > 0,
        1,
        0,
    )

    ### Imputing bad baseline
    baseline["baseline_rollavg"] = baseline.groupby(grouping_columns)[baseline_selected].transform(
        lambda s: s.rolling(roll_window, center=True, min_periods=1).mean()
    )
    
   # baseline["baseline_rollavg_5"] = baseline.groupby(grouping_columns)[baseline_selected].transform(
    #    lambda s: s.rolling(5, center=True, min_periods=1).mean()
    #)
    
    #logger.info("3Weeks MA starting")
    
    baseline["base_td_OLD"] = baseline[baseline_selected]
    baseline["econ_baseline"] = np.where(
        (baseline["EWB_bad_flag"] == 1) & (baseline["EWB_base_logic4"] == 0) & (baseline["EWB_base_logic5"] == 0) & (baseline["EWB_base_logic6"] == 0),
        baseline[volume],
        np.where(
            (baseline["EWB_bad_flag"] == 1) & (baseline["EWB_base_logic4"] != 0),
            baseline["baseline_rollavg"],np.where(
            (baseline["EWB_bad_flag"] == 1) & (baseline["EWB_base_logic5"] != 0),
             baseline["baseline_rollavg"],np.where((baseline["EWB_bad_flag"] == 1) & (baseline["EWB_base_logic6"] != 0),
             baseline["baseline_rollavg"],                                       
            baseline[baseline_selected],
        ))),
    )

    print("Finished bad baseline correction")

    return baseline

# %% [markdown]
# ##  helper function to add columns to have 9 pl columns in the baseline output

# %%
def create_nine_pl_cols(df):
    """ "
    helper function to add columns to have 9 pl columns in the baseline output
    Args:
        df : consolidated baseline output
    Returns:
        df : consolidated baseline output with 9 pl columns as "re_pl<>"
    """

    pl_cols_list = [col for col in df.columns if ("re_pl" in col) & ("bef_decay" not in col)]
    for i in range(len(pl_cols_list) + 1, 10):
        df["re_pl" + str(i)] = 0

    print("added pl colums upto 9 to baseline output.")

    return df

# %% [markdown]
# # Calling the functions in the baseline_module.py in the calculate_baseline function

# %%
def pad_month_number(column_name):
    match = re.search(r'_(\d)$', column_name)
    if match:
        padded_number = match.group(1).zfill(2)
        return re.sub(r'_(\d)$', f'_{padded_number}', column_name)
    return column_name

def changeMonth(df):
    df_make = df.copy()
    df_make.columns = [pad_month_number(col) for col in df_make.columns]
    return df_make


# %%
# print(final_result_df_og.filter(regex='^(fe_month_|re_month_)'))

final_result_df_og = changeMonth(final_results_og)
final_result_df = changeMonth(final_results)

# %%
print("Calculating baselines...")
baseline_data = data_for_baseline(raw_loess_all_f, data_for_modeling_f, params)
mb_df = merge_baseline(baseline_data, final_result_df, params)
cft_df = create_effect_terms(mb_df, params)
cdt_df = create_decomp_terms(cft_df, params)
cet_df = calculate_error_term(cdt_df, s1_res, s2_res, u1_res, u2_res, params)
final_df = create_final_baseline_coef(cet_df, params)
imputed_baseline = impute_bad_baseline(final_df, params)
imputed_baseline = create_nine_pl_cols(imputed_baseline)

### save the outputs
# write_obj(
#     imputed_baseline,
#     catalog["consolidated_baseline"]["filepath"],
#     catalog["consolidated_baseline"]["filename"],
#     catalog["consolidated_baseline"]["format"],
# )
#####
imputed_baseline.to_csv("./05_model_post_processing/own/consolidated_baseline.csv",index=False)
print("Finished calculating and imputing baselines successfully.")

# %%
baseline_og = pd.read_csv('./05_model_post_processing/consolidated_baseline.csv')
baseline_og = baseline_og[baseline_og['retailer_id'].isin(['SAMS CLUB'])]

# %%
print(baseline_og.shape)
print(imputed_baseline.shape)

# %%
baseline_og.to_csv("./05_model_post_processing/own/consolidated_baseline_sams-club.csv",index=False)


# %%



