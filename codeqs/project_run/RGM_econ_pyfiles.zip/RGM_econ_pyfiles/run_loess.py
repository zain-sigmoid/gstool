# %% [markdown]
# ### Location: src/models/loess.py

# %% [markdown]
# ### Function name: run_loess (This function is called in the pipeline)
# The input and output of the fuction are as follows:

# %% [markdown]
# """\
# Main function to run loess- calls all other functions\
# Args:\
#     data_for_loess_raw: Data output from the data prep step\
#     params : Parameters dictionary\
#     catalog : Dictionary of files locations\
# Returns:\
#     final_loess_df: dataframe with loess output\
# """

# %% [markdown]
# The function is called in the pipeline at line 121 as:\
# base_loess = run_loess(raw_loess_all, params, catalog)

# %% [markdown]
# raw_loess_all: Output of the dataprep\
# params: parameters in cofig file\
# catalog: file defining the paths (we will directly use the paths won't use this file)

# %% [markdown]
# ## Importing the Libararies

# %%
import bios
import os
import numpy as np
import pandas as pd

from typing import Dict

import rpy2.robjects as robjects
from pandas import DataFrame
from pygam import LinearGAM, f, l, s
from pyspark.sql.types import *
from rpy2.robjects import pandas2ri
from rpy2.robjects.conversion import localconverter
from sklearn.linear_model import LinearRegression
from statsmodels.nonparametric.smoothers_lowess import lowess
from termcolor import colored
"Copyright (c) 1997 Christian Michelsen Research AS Advanced Computing"
# %%
import importlib
import inter_methods

importlib.reload(inter_methods)
from inter_methods import InterMethods

methods = InterMethods()
UserPassword = "admin1234"
USERNAME = "zain"
# %% [markdown]
# ## Function to load all parameters file in yml format

# %%
### Path to this function: src/utils/config.py
def load_params(base: str):
    """
    Function to load parameters file in yml format into the environment
    Args:
        base : base location to project where the notebooks and parameters folders are present
    Returns:
        final_params: Dictionary of all parameter files present within the parameters folder ending with .yml
    """
    final_params = {}
    parameters_list = os.listdir(base + "/parameters")
    parameters_list = [i for i in parameters_list if i.endswith("yml")]
    for params in parameters_list:

        my_dict = bios.read(base + "/parameters/" + params)

        final_params.update(my_dict)

    return final_params

# %%
base_dir = os.getcwd()
params = load_params(base_dir)
print(base_dir)
### params will have all the parameters files which are in the parameters folder

# %% [markdown]
# ## Load the input file

# %%
data_for_loess_raw = pd.read_csv("./01_intermediate_outputs/rgm_econ_all_data.csv")

# %%
rgm_econ_all_samsclub = methods.filterDataFrame(data_for_loess_raw, retailer='SAMS CLUB')
methods.printShape(data_for_loess_raw, rgm_econ_all_samsclub)

# %% [markdown]
# We have the two input files: data_for_loess_raw & params, now we start the run_loess

# %% [markdown]
# ## Start of run_loess

# %% [markdown]
# ### Assigning the parameters

# %%
def log_volume(vol_col: str) -> str:
    """
    Helper function to append "log_" to the volume column name
    Args:
        vol_col: string column name of column containing volume info
    Returns:
        string column name with "log_" appended
    """
    return f"log_{vol_col}"

# %%
level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
use_loess_from_R = params["ewb"]["modeling"]["loess"]["use_loess_from_R"]["enabled"]
loess_indep_vars = params["ewb"]["modeling"]["loess"]["independent_features_linear"]
loess_degf = params["ewb"]["modeling"]["loess"]["use_loess_from_R"]["loess_degree"]
time_period = params["ewb"]["data_management"]["granularity"] + "_number"
granularity = params["ewb"]["data_management"]["granularity"]
min_weeks_months_loess = params["ewb"]["modeling"]["loess"]["min_weeks_months_loess"]
seasonality_term = params["ewb"]["modeling"]["common"]["seasonality_term"]

# dep = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
#     params["ewb"]["data_management"]["volume"]
# )
### Modified the code here to directly load the function
dep = log_volume(params["ewb"]["data_management"]["volume"])

# %%
print(use_loess_from_R)

# %%
grouping_cols = list(filter(None, [level_1] + [level_2] + [level_3]))

# filter data with enough observations
data_for_loess = data_for_loess_raw[
    data_for_loess_raw[f"{granularity}_count"] > min_weeks_months_loess
].reset_index(drop=True)

### Check min_weeks_months_loess is weeks or months

# %%
methods.printShape(data_for_loess_raw, data_for_loess)

# %% [markdown]
# # Functions for else statement when use_loess_from_R is False

# %%
print(f"is use from r paramter : {colored(use_loess_from_R,'yellow')}. If true then we will use loess.R")

# %% [markdown]
# The functions in this section are used only when the value use_loess_from_R is False. This functions below will calculate loess trend using the python.

# %% [markdown]
# ### Function for creating month identifier

# %%
def create_month_id(data: DataFrame, params: Dict):
    """
    Function to create month identifier from data
    Args:
        data:data for loess as pandas dataframe
        params: parameter dictionary
    Returns:
        data: Input dataframe with month column added
    """

    column_with_months = params["ewb"]["data_management"]["column_with_date"]
    data[column_with_months] = pd.to_datetime(data[column_with_months])
    data["month_id"] = data[column_with_months].dt.month

    return data

# %% [markdown]
# ### Function to develop regression model

# %%
def loess_regression_models(data_for_loess_sub: DataFrame, params: Dict) -> DataFrame:
    """
    Function to develop regression model and pass the output to mixed models
    Args:
        data_for_loess_sub:data for loess as pandas dataframe
        params: parameter dictionary
    Returns:
        data: data for loess as pandas dataframe with regression outputs added
    """

    data_for_loess_sub = create_month_id(data_for_loess_sub, params)

    if len(data_for_loess_sub) > 10:
#         volume_term = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
#             params["ewb"]["data_management"]["volume"]
#         )
        volume_term = log_volume(params["ewb"]["data_management"]["volume"])
        # price_term = params["ewb"]["modeling"]["common"]["price_term"]
        # acv_term = params["ewb"]["modeling"]["loess"]["acv_term"]
        seasonality_term = params["ewb"]["modeling"]["common"]["seasonality_term"]
        independent_features = params["ewb"]["modeling"]["loess"]["independent_features_linear"]
    
        intercept = params["ewb"]["modeling"]["loess"]["fit_intercept"]
        independent_features_non_seasonal = [
            i for i in independent_features if i not in [seasonality_term]
        ]

        if seasonality_term in independent_features:
            seasonal_dummies = pd.get_dummies(data_for_loess_sub["month_id"])
        #             print("seasonal values exist and dummies are computed")
        else:
            seasonal_dummies = pd.DataFrame()
        trend_term = params["ewb"]["data_management"]["granularity"] + "_number"
        data_for_loess_sub["trend_variable"] = data_for_loess_sub[[trend_term]]

        indep_data = pd.concat(
            [
                data_for_loess_sub[independent_features_non_seasonal + ["trend_variable"]],
                seasonal_dummies,
            ],
            axis=1,
        )

        X = indep_data.values
        y = data_for_loess_sub[volume_term].values

        regr = LinearRegression(fit_intercept=intercept)
        regr.fit(X, y)
        # print(i,j,"reg score -",regr.score(X, y))

        y_pred = regr.predict(X)

        data_for_loess_sub["error"] = data_for_loess_sub[volume_term] - y_pred

        coeff_df = pd.DataFrame(
            {
                "features": indep_data.columns,
                "coeffs": regr.coef_,
            }
        )

        coeff_linear = coeff_df[coeff_df.features == "trend_variable"]["coeffs"].values.tolist()[0]
        data_for_loess_sub["linear_term"] = data_for_loess_sub["trend_variable"] * coeff_linear

    return data_for_loess_sub

# %% [markdown]
# ### Function to gam model to estimate trend term

# %%
def loess_custom_models(data_for_loess_sub: DataFrame, params: Dict) -> list:
    """
    Function to gam model to estimate trend term
    Args:
        data_for_loess_sub:data for loess as pandas dataframe
        params: parameter dictionary
    Returns:
        data: loess prediction for every input record
    """

    time_period = params["ewb"]["data_management"]["granularity"] + "_number"
    target_gam = params["ewb"]["modeling"]["loess"]["target_gam"]
    span = params["ewb"]["modeling"]["loess"]["span"]

    X = data_for_loess_sub[[time_period]].values
    y = data_for_loess_sub[target_gam].values

    x_data = [item for sublist in X.tolist() for item in sublist]
    y_data = [item for sublist in y.tolist() for item in sublist]
    preds = lowess(y_data, x_data, frac=span)

    return preds

# %% [markdown]
# ### Function to gam model in python to estimate the trend term

# %%
def loess_gam_models(data_for_loess_sub: DataFrame, params: Dict) -> list:
    """
    Function to gam model to estimate trend term
    Args:
        data_for_loess_sub:data for loess as pandas dataframe
        params: parameter dictionary
    Returns:
        data: Gam prediction for every input record
    """

    time_period = params["ewb"]["data_management"]["granularity"] + "_number"
    target_gam = params["ewb"]["modeling"]["loess"]["target_gam"]
    intercept = params["ewb"]["modeling"]["loess"]["fit_intercept"]
    n_splines = params["ewb"]["modeling"]["loess"]["n_splines"]

    X = data_for_loess_sub[[time_period]].values
    y = data_for_loess_sub[target_gam].values

    gam = LinearGAM(s(0), fit_intercept=intercept)
    gam.gridsearch(X, y, lam=np.logspace(-3, 3, 10), n_splines=n_splines, progress=False)
    
    # lams = np.logspace(-3, 3, 10)
    # gam.gridsearch(X, y, lam=lams)
    preds = gam.predict(X)

    return preds

# %%
intercept = params["ewb"]["modeling"]["loess"]["fit_intercept"]
n_splines = params["ewb"]["modeling"]["loess"]["n_splines"]
print(intercept, n_splines)

# %% [markdown]
# ### Using the pygam as true to develop loess in python

# %%
def loess_prediction(data_for_loess: DataFrame, params: Dict) -> list:
    """
    Function to gam model to estimate trend term
    Args:
        data_for_loess:data for loess as pandas dataframe
        params: parameter dictionary
    Returns:
        data: Gam prediction for every input record
    """

#     volume_term = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
#         params["ewb"]["data_management"]["volume"]
#     )
    volume_term = log_volume(params["ewb"]["data_management"]["volume"])
    time_period = params["ewb"]["data_management"]["granularity"] + "_number"
    use_pygam = params["ewb"]["modeling"]["loess"]["use_pygam"]
    ### Using the pygam to get the results for python loess
    use_pygam = True


    data_for_loess_sub = loess_regression_models(data_for_loess, params)

    # y = data_for_loess_sub[target_gam].values #changed in client testing

    preds_loess = loess_custom_models(data_for_loess_sub, params)
    preds_loess_final = pd.DataFrame(preds_loess)[1].tolist()
    if use_pygam:
        
        print("calling loess_gam_models")
        preds_pygam = loess_gam_models(data_for_loess_sub, params)
        print("loess_gam_models build")

        dict_df = pd.DataFrame(
            {
                time_period: [
                    item for sublist in data_for_loess_sub[[time_period]].values for item in sublist
                ],
                "trend_pygam": preds_pygam,
                "linear_term": data_for_loess_sub["linear_term"].values,
            }
        )
        dict_df["trend_term"] = dict_df["trend_pygam"] + dict_df["linear_term"]
    else:
        dict_df = pd.DataFrame(
            {
                time_period: [
                    item for sublist in data_for_loess_sub[[time_period]].values for item in sublist
                ],
                "trend_loess": preds_loess_final,
                "linear_term": data_for_loess_sub["linear_term"].values,
            }
        )
        dict_df["trend_term"] = dict_df["trend_loess"] + dict_df["linear_term"]

    return dict_df

# %% [markdown]
# ### The else statement, here the loess model from python will be used

# %% [markdown]
# # Running IF ELSE statement

# %% [markdown]
# ### If and else for using loess from R

# %%
col_for_loess = list(
        filter(None, [level_1, level_2, level_3, time_period] + loess_indep_vars + [dep])
    )
data_for_loess_r = data_for_loess[col_for_loess]

# %%
data_for_loess_r.columns

# %%
#Walmart, Costco, Target, Dollar General and Sams Club
data_for_loess_r['retailer_id'].unique()

# %% [markdown]
# amazon : 9313 <br>
# costco: 103 <br>
# TARGET PT : 35430 <br>
# dollar general : 35988 <br>
# sams club : 4321 <br>
# walmart : 60300 <br>
# "GIANT EAGLE", "ALBSCO", "FOOD LION", "PUBLIX TOTAL TA", "SMART & FINAL", "OTHER TOTAL US FOOD"

# %%
filtered_df=data_for_loess_r[data_for_loess_r['retailer_id'].isin(["GIANT EAGLE", "ALBSCO", "FOOD LION", "PUBLIX TOTAL TA", "SMART & FINAL", "OTHER TOTAL US FOOD"])]
# filtered_df=data_for_loess_r[data_for_loess_r['retailer_id'].isin(['TARGET PT'])]
print(filtered_df.shape)

# %%
print(level_1, level_2, time_period)
methods.display(loess_indep_vars,msg="loess independent variables")
print(colored("loess dependent variable","yellow"),'\n',dep)

# %%
if use_loess_from_R:
    col_for_loess = list(
        filter(None, [level_1, level_2, level_3, time_period] + loess_indep_vars + [dep])
    )
    data_for_loess_r = data_for_loess[col_for_loess]

    # Defining the R script and loading the instance in Python
    r = robjects.r
    r["source"]("./models/loess.R")

    print(colored('loading function','yellow'))
    # Loading the function we have defined in R.
    loess_function_r = robjects.globalenv["loess_prediction"]

    print(colored('converting into r objects','yellow'))
    filtered_df=data_for_loess_r[data_for_loess_r['retailer_id'].isin(['WALMART TOTAL US TA','COSTCO','SAMS CLUB'])]

    # data_for_loess_r_small = data_for_loess_r.head(10)  # First 10 rows for example
    with localconverter(robjects.default_converter + pandas2ri.converter):
        df_r = robjects.conversion.py2rpy(filtered_df)

    # converting it into r object for passing into r function
    # Invoking the R function, calculating the LOESS trend and getting the result
    try:
        base_loess_r = loess_function_r(
            df_r, level_1, level_2, level_3, time_period, loess_degf, dep, loess_indep_vars
        )
    except Exception as e:
        print(colored("Error during R function execution:",'red'),e)
        raise

    # # Converting it back to a pandas dataframe.
    print(colored('converting back to pandas','green'))
    final_loess_df = pandas2ri.rpy2py(base_loess_r)
    final_loess_df = final_loess_df.merge(data_for_loess_raw, how="inner")
    
else:
    if len(level_3) > 0:
        predicted_dataframe = (
            data_for_loess.groupby([level_1, level_2, level_3])
            .apply(
                loess_prediction,
                params=params,
            )
            .reset_index()
        )
        final_loess_df = data_for_loess_raw.merge(
            predicted_dataframe[[level_1, level_2, level_3, time_period, "trend_term"]],
            on=[level_1, level_2, level_3, time_period],
            how="left",
        )

    else:
        predicted_dataframe = (
            data_for_loess.groupby([level_1, level_2])
            .apply(
                loess_prediction,
                params=params,
            )
            .reset_index()
        )

        final_loess_df = data_for_loess_raw.merge(
            predicted_dataframe[[level_1, level_2, time_period, "trend_term"]],
            on=[level_1, level_2, time_period],
            how="left",
        )
# save outputs
# write_obj(
#     final_loess_df,
#     catalog["loess_prediction"]["filepath"],
#     catalog["loess_prediction"]["filename"],
#     catalog["loess_prediction"]["format"],
# )
print("run_loess successfull!!, now save the outputs")

# %%
og_loess_pred = pd.read_csv('./04_model_results/loess/loess_prediction.csv')

# %%
filtered_og_loess_pred = og_loess_pred[og_loess_pred['retailer_id'].isin(['WALMART TOTAL US TA','COSTCO','SAMS CLUB'])]
print(filtered_og_loess_pred.shape)
filtered_og_loess_pred.to_csv("./04_model_results/loess/own/filtered_og_loess_pred.csv",index=False)

# %%
filtered_og_loess_pred.shape

# %% [markdown]
# ### Save the ouputs

# %%
final_loess = pd.read_csv("./04_model_results/loess/own/loess_prediction.csv")
final_loess.shape

# %%
final_loess_df.to_csv("./04_model_results/loess/own/loess_prediction.csv",index=False)

# %%
def match_row_column_product_with_categorical(df1, df2):
    """
    Matches the product of numeric columns and checks equality for categorical columns.

    Args:
        df1 (pd.DataFrame): First DataFrame.
        df2 (pd.DataFrame): Second DataFrame.

    Returns:
        dict: A dictionary with boolean DataFrames for numeric row/column product matches
              and categorical column matches.
    """
    numeric_df1 = df1.select_dtypes(include=['number'])
    numeric_df2 = df2.select_dtypes(include=['number'])
    
    # Row-wise product for numeric columns
    row_product_df1 = numeric_df1.prod(axis=1)
    row_product_df2 = numeric_df2.prod(axis=1)
    
    # Column-wise product for numeric columns
    column_product_df1 = numeric_df1.prod(axis=0)
    column_product_df2 = numeric_df2.prod(axis=0)
    
    # Align indices for row-wise comparison
    row_product_df1, row_product_df2 = row_product_df1.align(row_product_df2, join='inner')
    
    # Compare row-wise and column-wise products for numeric columns
    numeric_matches = {
        'Row Match': row_product_df1 == row_product_df2,
        'Column Match': column_product_df1 == column_product_df2
    }
    
    # Compare categorical columns
    categorical_df1 = df1.select_dtypes(include=['object', 'category'])
    categorical_df2 = df2.select_dtypes(include=['object', 'category'])
    
    categorical_matches = {}
    for col in categorical_df1.columns:
        if col in categorical_df2.columns:
            categorical_df1_col, categorical_df2_col = categorical_df1[col].align(categorical_df2[col], join='inner')
            categorical_matches[col] = categorical_df1_col.equals(categorical_df2_col)
        else:
            categorical_matches[col] = False

    # Combine results
    result = {
        'Numeric Matches': numeric_matches,
        'Categorical Matches': categorical_matches
    }
    
    return result

# %%
# Run the function
result = match_row_column_product_with_categorical(filtered_og_loess_pred, final_loess)

# %%
result_row_df = pd.DataFrame(result['Numeric Matches']['Column Match']).reset_index()
result_col_df = pd.DataFrame(list(result['Categorical Matches'].items()))
merge_res = [result_row_df,result_col_df]
resultdf = pd.concat(merge_res,ignore_index=True)

# %%
resultdf.to_clipboard()

# %%



