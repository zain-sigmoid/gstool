# %% [markdown]
# ### Path: src/models/automated_pl_run.py

# %% [markdown]
# """\
# Master function to run design 2 of pantry loading\
# Args:\
#     base_loess: output dataframe from loess\
#     params: parameters dictionary\
#     catalog : catalog dictionary\
# Returns:\
#     s1 : dataframe of model results for structured without cpi\
#     s2 : dataframe of model results for structured with cpi\
#     u1 : dataframe of model results for unstructured without cpi\
#     u2 : dataframe of model results for unstructured with cpi\
#     fe_dict : fixed effects formula dictionary\
# """

# %% [markdown]
# This function is called at line 155 in the code as:\
# (consolidated_results,\
# consolidated_results_good_pairs,\
# s1_res,\
# s2_res,\
# u1_res,\
# u2_res,\
# ) = automated_pl_run(base_loess, params, catalog, raw_loess_all, raw_loess_all)

# %% [markdown]
# ## Importing libraries

# %%
import bios
import os
import json

# %%
import julia
from julia.api import Julia

jl = Julia(compiled_modules=False)

# %%
from julia import Main

# Main.eval(
#     """
#     using Pkg;
#     Pkg.add(Pkg.PackageSpec(name="CSV", version="0.10.4"));
#     Pkg.add(Pkg.PackageSpec(name="DataFrames", version="1.3.5"));
#     Pkg.add(Pkg.PackageSpec(name="StatsBase", version="0.33.21"));
#     Pkg.add("LinearAlgebra");
#     Pkg.add(Pkg.PackageSpec(name="StatsModels", version="0.6.28"));
#     Pkg.add(Pkg.PackageSpec(name="MixedModels", version="3.9.0"));
#     Pkg.add(Pkg.PackageSpec(name="Pandas", version="1.6.1"));
#     Pkg.add(Pkg.PackageSpec(name="PyCall", version="1.94.1"));
#     Pkg.add(Pkg.PackageSpec(name="BlockArrays", version="0.11.2"))
#     """
# )

# added
Main.eval(
    """
    using Pkg;
    Pkg.add(Pkg.PackageSpec(name="CSV", version="0.10.15"));
    Pkg.add(Pkg.PackageSpec(name="DataFrames", version="1.7.0"));
    Pkg.add(Pkg.PackageSpec(name="StatsBase", version="0.34.4"));
    Pkg.add("LinearAlgebra");
    Pkg.add(Pkg.PackageSpec(name="StatsModels", version="0.7.4"));
    Pkg.add(Pkg.PackageSpec(name="MixedModels", version="4.28.0"));
    Pkg.add(Pkg.PackageSpec(name="Pandas", version="1.6.1"));
    Pkg.add(Pkg.PackageSpec(name="PyCall", version="1.96.4"));
    """
)

# %%
import itertools
import re as reg
from typing import Dict, List, Set, Tuple

import numpy as np
import pandas as pd
from julia import DataFrames, Main, Pandas, Julia
from scipy.stats import t

# %% [markdown]
# # Function to load all parameters in yml format

from typing import Any

# -> dict[str, Any]


# %%
### Path to this function: src/utils/config.py
def load_params(base: str):
    """
    Function to load parameters file in yml format into the environment
    Args:
        base : base location to project where the notebooks and parameters folders are present
    Returns:
        final_params: Dictionary of all parameter files present within the parameters folder ending with .yml
    """
    final_params = {}
    parameters_list = os.listdir(base + "/parameters")
    parameters_list = [i for i in parameters_list if i.endswith("yml")]
    for params in parameters_list:

        my_dict = bios.read(base + "/parameters/" + params)

        final_params.update(my_dict)

    return final_params


# %%
base_dir = os.getcwd()
params = load_params(base_dir)
### params will have all the parameters files which are in the parameters folder

# %% [markdown]
# # Load the input files

# %%
base_loess = pd.read_csv("./04_model_results/loess/loess_prediction.csv")
raw_loess_all = pd.read_csv("./01_intermediate_outputs/rgm_econ_all_data.csv")

# %%
print(raw_loess_all.shape)
print(base_loess.shape)

# %%
base_loess_f = base_loess[base_loess["retailer_id"].isin(["SAMS CLUB"])]
# raw_loess_all = raw_loess_all[raw_loess_all['retailer_id'].isin(['WALMART TOTAL US TA', 'COSTCO', 'SAMS CLUB'])]
raw_loess_all_f = raw_loess_all[raw_loess_all["retailer_id"].isin(["SAMS CLUB"])]

# %%
print(raw_loess_all_f.shape)
print(base_loess_f.shape)

# %% [markdown]
# # Start of automated_pl_run

# %% [markdown]
# ## Parameters loading

# %%
# modeling params
re_structured = params["ewb"]["modeling"]["mixed_models"]["re_structured"]
re_structured_cpi = params["ewb"]["modeling"]["mixed_models"]["re_structured_cpi"]
re_unstructured = params["ewb"]["modeling"]["mixed_models"]["re_unstructured"]
re_unstructured_cpi = params["ewb"]["modeling"]["mixed_models"]["re_unstructured_cpi"]
vars_add_logic = params["ewb"]["modeling"]["quality"]["vars_add_logic"]


# %%
def pantry_loading_func(num_pl_features):
    """
    Helper function to create colnames for pantry loading features
    Args:
        num_pl_features: int
            Number of pantry loading features
    Returns:
        pl_features_names: str
            List of pantry loading features names
    """
    pl_features_names = [f"pl{i}" for i in range(1, num_pl_features + 1)]
    return pl_features_names


def all_pantry_loading_list(num_pl_features):
    """
    Helper function to create a nested list of colnames for pantry loading features
    Args:
        num_pl_features: int
            Number of pantry loading features
    Returns:
        possible_pl_features_names: str
            List of list of possible pantry loading features names
    """
    possible_pl_features_names = []
    for i in range(3, num_pl_features + 1):
        possible_pl_features_names.append(pantry_loading_func(i))
    return possible_pl_features_names


# %%
# pantry loading params
oot_pred = params["ewb"]["data_management"]["oot_pred"]
all_pl_list = all_pantry_loading_list(
    params["ewb"]["data_management"]["max_pantry_flags"]
)
pantry_loading = pantry_loading_func(params["ewb"]["data_management"]["pantry_flags"])

# %% [markdown]
# ## if-else for oot_pred, which is false so directly skipping to else statement

# %%
# if oot_pred:

#     for pl_list in all_pl_list:

#         logger.info("Running mixed models in a loop...")
#         logger.info(f"Running loop for {pl_list}")
#         re_structured_new = process_pl_func(re_structured, pl_list)
#         re_unstructured_new = process_pl_func(re_unstructured, pl_list)
#         re_structured_cpi_new = process_pl_func(re_structured_cpi, pl_list)
#         re_unstructured_cpi_new = process_pl_func(re_unstructured_cpi, pl_list)
#         vars_add_logic_new = process_pl_func(vars_add_logic, pl_list)

#         s1, s2, u1, u2, fe_dict, s1_res, s2_res, u1_res, u2_res = run_mixed_models(
#             base_loess,
#             params,
#             catalog,
#             re_structured_new,
#             re_structured_cpi_new,
#             re_unstructured_new,
#             re_unstructured_cpi_new,
#             pl_list,
#         )

#         logger.info("Consolidating model results for insample")
#         consolidated_df = consolidate_model_results(
#             s1,
#             s2,
#             u1,
#             u2,
#             raw_loess_all_insample,
#             params,
#             fe_dict,
#             catalog,
#             vars_add_logic_new,
#             pl_list,
#         )

#         logger.info("Running coefficient imputation code...")
#         coef_to_impute = get_coefs_to_impute(consolidated_df)
#         consolidated_results, consolidated_results_good_pairs = perform_imputation(
#             consolidated_df, params, coef_to_impute, catalog, pl_list
#         )

#         logger.info("Running pantry loading decay code...")
#         consolidated_results = pantry_loading_decay(consolidated_results, catalog, pl_list)

#         logger.info("Calculating prediction for OOT period...")
#         make_prediction(consolidated_results, catalog, params, pl_list)

#         logger.info(f"loop run complete for {pl_list}")

#     return consolidated_results, consolidated_results_good_pairs, s1_res, s2_res, u1_res, u2_res

# else:
#     logger.info("Running mixed models once")
#     re_structured_new = process_pl_func(re_structured, pantry_loading)
#     re_unstructured_new = process_pl_func(re_unstructured, pantry_loading)
#     re_structured_cpi_new = process_pl_func(re_structured_cpi, pantry_loading)
#     re_unstructured_cpi_new = process_pl_func(re_unstructured_cpi, pantry_loading)
#     vars_add_logic_new = process_pl_func(vars_add_logic, pantry_loading)

#     s1, s2, u1, u2, fe_dict, s1_res, s2_res, u1_res, u2_res = run_mixed_models(
#         base_loess,
#         params,
#         catalog,
#         re_structured_new,
#         re_structured_cpi_new,
#         re_unstructured_new,
#         re_unstructured_cpi_new,
#         pantry_loading,
#     )

#     logger.info("Consolidating model results for all data")
#     consolidated_df = consolidate_model_results(
#         s1,
#         s2,
#         u1,
#         u2,
#         raw_loess_all,
#         params,
#         fe_dict,
#         catalog,
#         vars_add_logic_new,
#         pantry_loading,
#     )

#     logger.info("Running coefficient imputation code...")
#     coef_to_impute = get_coefs_to_impute(consolidated_df)
#     consolidated_results, consolidated_results_good_pairs = perform_imputation(
#         consolidated_df, params, coef_to_impute, catalog, pantry_loading
#     )

#     logger.info("Running pantry loading decay code...")
#     consolidated_results = pantry_loading_decay(consolidated_results, catalog, pantry_loading)

#     logger.info("Calculating prediction for OOT period skipped")

#     logger.info(f"single run complete for {pantry_loading}")

#     return consolidated_results, consolidated_results_good_pairs, s1_res, s2_res, u1_res, u2_res

# %% [markdown]
# # The else statement if oot_pred, else:

# %% [markdown]
# ## Processing before calling the run_mixed_models


# %%
### Path to the function: src/utils/utils.py
def flatten_list(input_list):
    """
    Helper function to flatten a list
    Args:
        input_list: a nested list
    Returns:
    flat_list: a flattened list
    """
    flat_list = []
    # Iterate through the outer list
    for element in input_list:
        if type(element) is list:
            # If the element is of type list, iterate through the sublist
            for item in element:
                flat_list.append(item)
        else:
            flat_list.append(element)
    return flat_list


def process_pl_func(variable, pl_list):
    """
    Helper function to process a function inside the list and flatten it from a nested loop
    Args:
        variable: a variable to be loaded
        pl_list: list of pl variables
    Returns:
        variable: loaded variable
    """
    intermediate = variable.copy()
    # intermediate[-1] = load_func(variable[-1])(len(pl_list))
    ### load_func(variable[-1]) in the below cells will load the pantry_loading_func
    intermediate[-1] = pantry_loading_func(len(pl_list))

    variable = flatten_list(intermediate)
    return variable


# %%
print("Running mixed models once")
re_structured_new = process_pl_func(re_structured, pantry_loading)
re_unstructured_new = process_pl_func(re_unstructured, pantry_loading)
re_structured_cpi_new = process_pl_func(re_structured_cpi, pantry_loading)
re_unstructured_cpi_new = process_pl_func(re_unstructured_cpi, pantry_loading)
vars_add_logic_new = process_pl_func(vars_add_logic, pantry_loading)

# %% [markdown]
# # Calling the run_mixed_models

# %%
# s1, s2, u1, u2, fe_dict, s1_res, s2_res, u1_res, u2_res = run_mixed_models(
#     base_loess,
#     params,
#     # catalog,
#     re_structured_new,
#     re_structured_cpi_new,
#     re_unstructured_new,
#     re_unstructured_cpi_new,
#     pantry_loading,
# )

# %% [markdown]
# ## Helper functions for run_mixed_models function

# %% [markdown]
# ### Function to load the functions from the notebook


# %%
def load_func(dotpath: str):
    """
    Helper function to load a function in the current notebook and return a function for later execution.
    Function is right-most segment.
    Args:
        dotpath: function path (ignored)
    Returns:
        Function that accepts arguments and calls the loaded function.
    """
    func_name = dotpath.split(".")[-1]
    func = globals().get(func_name)
    if func is None:
        raise ValueError(f"Function '{func_name}' not found in the global namespace.")
    if not callable(func):
        raise ValueError(f"'{func_name}' is not callable.")

    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


# %% [markdown]
# ### Function to prepare data for mixed_models

# %%
# def prep_data_for_MM(
#     data: pd.DataFrame, params: Dict, ###catalog: Dict
# ) -> Tuple[pd.DataFrame, pd.DataFrame]:
#     """
#     Pre-processes the data for mixed-model fitting -
#     adding required columns,
#     converting relevant columns to category, and
#     adding a dummy row of data to bypass Julia MM errors
#     Args:
#         data : pandas dataframe
#         params : parameter dict
#         catalog: dict of input/output filepaths
#     Returns:
#         data_to_fit : final dataframe used for model fitting
#         data : original dataframe with added calculated columns
#     """

#     # getting params
#     level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
#     level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
#     level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
#     volume = params["ewb"]["data_management"]["volume"]
#     seasonality = params["ewb"]["modeling"]["common"]["seasonality_term"]

#     print("Starting data prep for mixed modeling")

#     grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

#     # filtering only good pairs
#     data_trimmed = data[data["general_flag"] == "GOOD"].reset_index(drop=True)
#     # Summing volume by the levels and adding to main dataset
#     data_trimmed["vol_total"] = data_trimmed.groupby(grouping_columns)[volume].transform("sum")

#     # Column to categorize
#     factor_columns = list(filter(None, [level_1] + [level_2] + [level_3] + [seasonality]))

#     # Adding dummy categories to avoid 'one-level error in Julia'
#     dummy_row = data_trimmed.head(1).copy()
#     dummy_row[factor_columns] = "dummy"
#     data_to_fit = pd.concat([data_trimmed, dummy_row], ignore_index=True)

#     # convert all the grouping columns to type string
#     data_to_fit[grouping_columns] = data_to_fit[grouping_columns].astype(str)

#     # Adding unique values in order to handle nested effects (creating a new field with all levels combined)
#     data_to_fit["__".join(grouping_columns)] = (
#         (data_to_fit[grouping_columns] + "__").sum(axis=1).str.rstrip("__")
#     )  # rstrip removes the trailing '__'

#     # Converting required variables to category
#     data_to_fit[factor_columns] = data_to_fit[factor_columns].astype("category")

#     # write_data_to_csv(
#     #     data_to_fit,
#     #     catalog["data_to_fit"]["filepath"]
#     #     + catalog["data_to_fit"]["filename"]
#     #     + "."
#     #     + catalog["data_to_fit"]["format"],
#     # )
#     data_to_fit.to_csv("01_intermediate_outputs/own/data_to_fit.csv",index=False)
#     print("Data prep for mixed modeling finished and written to output successfully")


#     return data_to_fit, data_trimmed
def prep_data_for_MM(
    data: pd.DataFrame,
    params: Dict,  ###catalog: Dict
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Pre-processes the data for mixed-model fitting -
    adding required columns,
    converting relevant columns to category, and
    adding a dummy row of data to bypass Julia MM errors
    Args:
        data : pandas dataframe
        params : parameter dict
        catalog: dict of input/output filepaths
    Returns:
        data_to_fit : final dataframe used for model fitting
        data : original dataframe with added calculated columns
    """

    # getting params
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    volume = params["ewb"]["data_management"]["volume"]
    seasonality = params["ewb"]["modeling"]["common"]["seasonality_term"]

    print("Starting data prep for mixed modeling")

    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

    # filtering only good pairs
    print("data-prep: filtering goog pairs")
    data_trimmed = data[data["general_flag"] == "GOOD"].reset_index(drop=True)
    # Summing volume by the levels and adding to main dataset
    data_trimmed["vol_total"] = data_trimmed.groupby(grouping_columns)[
        volume
    ].transform("sum")

    # Column to categorize
    factor_columns = list(
        filter(None, [level_1] + [level_2] + [level_3] + [seasonality])
    )

    # Adding dummy categories to avoid 'one-level error in Julia'
    print("data-prep:Adding dummy categories to avoid one-level error in Julia")
    dummy_row = data_trimmed.head(1).copy()
    dummy_row[factor_columns] = "dummy"
    data_to_fit = pd.concat([data_trimmed, dummy_row], ignore_index=True)

    # convert all the grouping columns to type string
    print("data-prep: convert all the grouping columns to type string")
    data_to_fit[grouping_columns] = data_to_fit[grouping_columns].astype(str)

    # Adding unique values in order to handle nested effects (creating a new field with all levels combined)
    data_to_fit["__".join(grouping_columns)] = (
        (data_to_fit[grouping_columns] + "__").sum(axis=1).str.rstrip("__")
    )  # rstrip removes the trailing '__'

    # Converting required variables to category
    data_to_fit[factor_columns] = data_to_fit[factor_columns].astype("category")

    # write_data_to_csv(
    #     data_to_fit,
    #     catalog["data_to_fit"]["filepath"]
    #     + catalog["data_to_fit"]["filename"]
    #     + "."
    #     + catalog["data_to_fit"]["format"],
    # )
    print("data-prep:saving data")
    data_to_fit.to_csv("01_intermediate_outputs/own/data_to_fit.csv", index=False)
    print("Data prep for mixed modeling finished and written to output successfully")

    return data_to_fit, data_trimmed


# %% [markdown]
# ## Function fit_and_predict where the julia script will be called

# %% [markdown]
# ### Function to prepare formula for mixed model


# %%
def log_volume(vol_col: str) -> str:
    """
    Helper function to append "log_" to the volume column name
    Args:
        vol_col: string column name of column containing volume info
    Returns:
        string column name with "log_" appended
    """
    return f"log_{vol_col}"


# %%
def prepare_formula_for_MM(
    params: dict[Any], fixed_effects: List[str], random_effects: List[str], group: str
) -> List[str]:
    """
    Prepares the formula for Julia mixed model function
    For info on formula creation: refer https://juliastats.org/MixedModels.jl/dev/constructors/
    Args:
        params : parameter dict
        fixed_effects: list of fixed effect interactions
        random_effects: list of random effect interactions
        group: string with grouping columns
    Returns:
        fm: string containing the complete formula with dependent and independent variables and fe and re interactions
        fe: fixed_effects portion of the mixed model formula
        re: random effects portion of the mixed model formula
    """

    target = load_func(params["ewb"]["modeling"]["common"]["target_var"])(
        params["ewb"]["data_management"]["volume"]
    )

    fe = " + ".join("&".join(item) for item in fixed_effects)
    re = (
        " + ".join(["((0 + " + sub + ")|" + group + ")" for sub in random_effects])
        + " + (1|"
        + group
        + ")"
    )

    fm = target + " ~ 0 + " + fe + " + " + re
    print(f"Formula prepared for mixed modeling: \n{fm}")

    return fm, fe, re


# %% [markdown]
# ### Function get random effect stats


# %%
def get_random_effects_stats(
    rand_eff: pd.DataFrame, var: List[float], dof, grouping_columns: List[str]
) -> pd.DataFrame:
    """
    Calculates and formats all the stats for the random effect coefficients
    Args:
        rand_eff : conditional modes of the random effects in model
        var : conditional variances matrices of the random effects
        dof : degrees of freedom for the model
        grouping_columns : levels 1, 2, 3
    Returns:
        random_dt : coefficients and other stats pertaining to the random effects
    """

    group = "__".join(grouping_columns)

    random_dt = rand_eff.melt(id_vars=[group], var_name="effect", value_name="estimate")
    group_df = random_dt[group].str.split("__", 0, expand=True)
    group_df.columns = grouping_columns
    random_dt = pd.concat([random_dt, group_df], axis=1)
    i = 0
    variances = []
    for arr in var[0]:
        variances.append(list(arr[i]))
        i = i + 1

    random_dt["var"] = list(itertools.chain.from_iterable(variances))
    random_dt["stderr"] = np.sqrt(random_dt["var"])
    random_dt["t_val"] = random_dt["estimate"] / random_dt["stderr"]
    random_dt["probt"] = 2 * t.cdf(-random_dt["t_val"].abs(), df=dof).round(3)
    random_dt["probt"] = random_dt["probt"].fillna(0)
    random_dt = random_dt[~random_dt[group].str.contains("dummy")].reset_index(
        drop=True
    )
    random_dt.drop(columns=["var", "stderr", "t_val"], inplace=True)
    random_dt["effect"] = random_dt["effect"].apply(
        lambda row: reg.sub("\(|\)", "", row).lower()
    )
    random_dt = random_dt.rename(columns={group: "subject"})

    return random_dt


# %% [markdown]
# ### Function to get fixed effect stats

# %% [markdown]
# #### Function to get effect column names from fixed effect part

# %%
import re


# %%
def get_effect_colnames(fixed_effect: str) -> List[str]:
    """
    Function to get effect column names from fixed effect part of modeling equation
    Args:
        fixed_effect: string from modeling equation
    Returns:
        list: list of columns for fixed effect
    """
    result = fixed_effect.split("+")
    result = [r for r in result if "&" in r]
    result = [re.sub("^(.*?)&", "", r) for r in result]
    result = [a.strip() for r in result for a in r.split("&")]
    return list(set(result))


# %% [markdown]
# #### Function similar to a melt function like converting column values to column headers


# %%
def convert_value_to_label(row: pd.Series) -> pd.Series:
    """
    Similar to a melt function - converts column values to column headers with
    column values coming from a different column
    Args:
        row : row of data from dataframe
    Returns:
        row : newly constructed row of data
    """
    # get label and value
    label = row["valued_vars"]
    value = row["subject"]

    # create column for label if it exists, don't create
    row[label] = value

    # return new row
    return row


# %% [markdown]
# #### Function to get the fixed effect stats


# %%
def get_fixed_effects_stats(
    fixed_stats: pd.DataFrame, fe: str, categ_cols: Set[str]
) -> pd.DataFrame:
    """
    Calculates and formats all the stats for the fixed effect coefficients
    Args:
        fixed_stats : stats of the fixed effect coefficients
        fe : fixed effects portion of the mixed model formula
        categ_cols : set for category columns
    Returns:
        fixed_dt : coefficients and other stats pertaining to the fixed effects
    """

    fixed_dt = fixed_stats[
        (fixed_stats["effect"].str.contains("dummy") == False)
        & (fixed_stats["estimate"] != 0)
    ].reset_index(drop=True)

    effect_colnames = get_effect_colnames(fe)
    effect_cols = set(effect_colnames).intersection(categ_cols)

    # parse main effects
    # Main effects are those that have no interactions
    main_effect_vars = [effect.strip() for effect in fe.split("+") if "&" not in effect]
    for var in main_effect_vars:
        fixed_dt["effect"] = np.where(
            fixed_dt["effect"].str.contains(var),
            fixed_dt["effect"].str.replace(": ", "_"),
            fixed_dt["effect"],
        )
    fixed_dt["valued_vars"] = fixed_dt.apply(
        lambda row: "".join([var for var in effect_cols if (var in row["effect"])]),
        axis=1,
    )

    # restructuring the dataset
    single_vars = [x.strip() for x in reg.split("&|\+", fe)]
    fixed_dt["single_vars"] = fixed_dt.apply(
        lambda row: [
            var
            for var in set(single_vars).difference(effect_cols)
            if (var in row["effect"])
        ],
        axis=1,
    )
    fixed_dt["subject"] = fixed_dt["effect"].apply(
        lambda row: (
            row.split(": ")[-1]
            if (":" and "&" in row) or (":" and "dummy" in row)
            else ""
        )
    )

    def remove_subject_from_effect(effect_str):
        subject_lst = [subj for subj in fixed_dt["subject"].unique() if subj]
        sub_in_eff = [subject for subject in subject_lst if subject in effect_str]
        for subject in sub_in_eff:
            if subject in effect_str:
                effect_str = (
                    effect_str.replace(subject, "").replace(": ", "").replace("&", "_")
                )
                effect_str = re.sub(" ", "", effect_str)
        return effect_str

    fixed_dt["effect"] = fixed_dt["effect"].apply(
        lambda row: remove_subject_from_effect(row)
    )
    fixed_dt["effect"] = fixed_dt["effect"].apply(lambda x: x.replace(": ", "_"))

    # convert the row values of valued_vars to separate column names so that each effect has its own column
    fixed_dt = fixed_dt.apply(
        lambda row: convert_value_to_label(row) if row["valued_vars"] != "" else row,
        axis=1,
    )

    # remove columns for label and values
    fixed_dt.drop(
        columns=["valued_vars", "subject", "single_vars"], axis=1, inplace=True
    )
    # filling nas with blanks for main effects vars which do not have any interactions and therefore no subjects
    fixed_dt[list(effect_cols)] = fixed_dt[list(effect_cols)].fillna("")

    return fixed_dt


# %% [markdown]
# ### fit_and_predict function


# %%
def fit_and_predict(
    data_to_fit: pd.DataFrame,
    # catalog: dict,
    params: dict,
    f_eff: List[str],
    r_eff: List[str],
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, str]:
    """
    Calls the Julia mixed modeling script to build and fit the elasticity model and predict on data
    Args:
        data_to_fit : pandas dataframe containing the data to use for fitting
        catalog : dict of input/output filepaths
        params : parameter dict
        f_eff : parameter containing the fixed effect variables
        r_eff : parameter containing the random effect variables
    Returns:
        results : final dataframe containing all the data along with predictions and residuals from the model
        fixed_dt : coefficients and other stats pertaining to the fixed effects
        random_dt : coefficients and other stats pertaining to the random effects
        fe : formula for fixed effects
    """

    # extracting parameters
    # data_filepath = (
    #     catalog["data_to_fit"]["filepath"]
    #     + catalog["data_to_fit"]["filename"]
    #     + "."
    #     + catalog["data_to_fit"]["format"]
    # )
    data_filepath = "01_intermediate_outputs/data_to_fit.csv"
    level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))
    group = "__".join(grouping_columns)

    # preparing the mixed model formula
    fm, fe, re = prepare_formula_for_MM(params, f_eff, r_eff, group)

    # calling julia mixed model script
    jl = Julia(compiled_modules=False)
    Main.fm = fm
    mixed_model_fn = jl.include("./models/mixed_models.jl")
    (
        residuals,
        pred,
        rand_eff,
        effect,
        estimate,
        stderr,
        z_value,
        p_value,
        var,
        dof,
    ) = mixed_model_fn(data_filepath, Main.fm)
    print("Mixed model built successfully")

    # adding predictions and residuals to dataset
    data_to_fit["pred"] = pred
    data_to_fit["resid"] = residuals
    # removing the dummy row and finalizing the results dataframe
    results = data_to_fit[data_to_fit[level_1] != "dummy"].reset_index(drop=True)

    # extracting the significance of random effects estimates, and other stats
    random_dt = Pandas.DataFrame(rand_eff).sort_values(
        by=[group], key=lambda col: col.str.lower()
    )
    random_dt = get_random_effects_stats(random_dt, var, dof, grouping_columns)

    # extracting the significance of fixed effects estimates, and other stats
    fixed_dt = pd.DataFrame(
        zip(effect, estimate, stderr, z_value, p_value),
        columns=["effect", "estimate", "stderr", "z_value", "p_value"],
    )
    categ_cols = data_to_fit.select_dtypes(
        include=["object", "category"]
    ).columns.tolist()
    fixed_dt = get_fixed_effects_stats(fixed_dt, fe, categ_cols)

    return results, fixed_dt, random_dt, fe


# %% [markdown]
# ## Function to create results, Master function to create model summaries

# %% [markdown]
# ### Functions to prepare random effect and fixed effect for merging into results dataframe


# %%
def prepare_random_effect(
    random_dt: pd.DataFrame, lvl1: str, lvl2: str, lvl3: str
) -> pd.DataFrame:
    """
    Function to prepare random effect for merging into results dataframe
    Args:
        random_dt: dataframe with random effects
        lvl1: level of aggregation from params
        lvl2: level of aggregation from params
        lvl3: level of aggregation from params
    Returns:
        rand_eff_transpose: dataframe ready for merge
    """
    random_dt["effect"] = "re_" + random_dt["effect"]
    rand_eff_transpose = pd.pivot_table(
        random_dt,
        index=list(filter(None, [lvl1] + [lvl2] + [lvl3])),
        columns="effect",
        values="estimate",
    ).reset_index()
    return rand_eff_transpose


# %%
def prepare_fixed_effect(fixed_coeff_full: pd.DataFrame) -> pd.DataFrame:
    """
    Function to prepare fixed effect for merging into results dataframe
    Args:
        fixed_coeff_full: dataframe with fixed effects
    Returns:
        fixed_coeff_full: dataframe with fixed effect
    """
    fixed_coeff_full["effect"] = "fe_" + fixed_coeff_full["effect"]
    return fixed_coeff_full


# %% [markdown]
# ### Function to prepare pair results dataframe

# %% [markdown]
# #### Helper functions for preparing pair results


# %%
def get_col_effects_levels(
    fixed_coeff_full, fixed_effect: str, lvl1: str, lvl2: str, lvl3: str
) -> Tuple[List[str], List[str]]:
    """
    Function to get levels for merging fixed effect and pairwise results
    Args:
        fixed_coeff_full: dataframe with fixed effects
        fixed_effect: string from modeling equation
        lvl1: level of aggregation from params
        lvl2: level of aggregation from params
        lvl3: level of aggregation from params
    Returns:
        lvls_to_explore: possible merge columns
        col_effects_levels: columns with fixed effect
    """
    # using for merge pair_results lvls and fixed effects by formula ?WHAT
    lvls_to_explore = get_effect_colnames(fixed_effect)
    lvls_to_explore = [
        lvl for lvl in lvls_to_explore if lvl in fixed_coeff_full.columns
    ]
    col_effects_levels = list(
        set(filter(None, lvls_to_explore + [lvl1] + [lvl2] + [lvl3]))
    )
    return lvls_to_explore, col_effects_levels


# %%
def prepare_pairs_results(
    mod_data: pd.DataFrame,
    unit_approach_flag: bool,
    value: str,
    volume: str,
    price: str,
    actual_units: str,
    col_effects_levels: List[str],
) -> pd.DataFrame:
    """
    Function to prepare pair results dataframe
    Args:
        mod_data: dataframe modeling data
        unit_approach_flag: unit_approach_flag from params
        value: value column from params
        volume: volume column from params
        price: price column from params
        actual_units: actual units column from params to be used if unit_approach_flag is True
        col_effects_levels: levels of effect from get_col_effects_levels function
    Returns:
        pairs_results: pairwise results dataframe
    """

    if unit_approach_flag:
        pairs_results = (
            mod_data.groupby(by=col_effects_levels)
            .agg(
                value=(value, "sum"),
                volume=(volume, "sum"),
                mean_price=(price, "mean"),
                std_avg_price=(price, "std"),
                min_avg_price=(price, "min"),
                max_avg_price=(price, "max"),
                avg_volume=(volume, "mean"),
                avg_units=(actual_units, "mean"),
            )
            .reset_index()
        )
    else:
        pairs_results = (
            mod_data.groupby(by=col_effects_levels)
            .agg(
                value=(value, "sum"),
                volume=(volume, "sum"),
                mean_price=(price, "mean"),
                std_avg_price=(price, "std"),
                min_avg_price=(price, "min"),
                max_avg_price=(price, "max"),
                avg_volume=(volume, "mean"),
            )
            .reset_index()
        )
    pairs_results["cv_price"] = (
        pairs_results["std_avg_price"] / pairs_results["mean_price"] * 100
    )
    return pairs_results


# %% [markdown]
# #### Function to prepare pair results dataframe


# %%
def merge_pairs_to_fixed(
    fixed_coeff_full: pd.DataFrame,
    mod_data: pd.DataFrame,
    fixed_effect: str,
    unit_approach_flag: bool,
    value: str,
    volume: str,
    price: str,
    actual_units: str,
    lvl1: str,
    lvl2: str,
    lvl3: str,
) -> pd.DataFrame:
    """
    Function to prepare pair results dataframe
    Args:
        fixed_coeff_full: fixed effects from modeling
        mod_data: modeling data
        fixed_effect: fixed effect part of modeling equation string
        unit_approach_flag: unit approach flag
        value: value column
        volume: volume column
        price: price column
        actual_units: actual units column to be used when unit approach flag is True
        lvl1: level of aggregation
        lvl2: level of aggregation
        lvl3: level of aggregation
    Returns:
        pairs_results: pairwise results dataframe
    """
    possible_keys = fixed_coeff_full.copy()
    lvls_to_explore, col_effects_levels = get_col_effects_levels(
        fixed_coeff_full, fixed_effect, lvl1, lvl2, lvl3
    )
    pairs_results = prepare_pairs_results(
        mod_data,
        unit_approach_flag,
        value,
        volume,
        price,
        actual_units,
        col_effects_levels,
    )

    fixed_coeff_full_obj = fixed_coeff_full.select_dtypes(["object"])
    fixed_coeff_full[fixed_coeff_full_obj.columns] = fixed_coeff_full_obj.apply(
        lambda x: x.str.strip()
    )
    fixed_coeff_full[fixed_coeff_full_obj.columns] = fixed_coeff_full[
        fixed_coeff_full_obj.columns
    ].fillna("")

    for lvl in lvls_to_explore:
        possible_keys[lvl] = np.where(possible_keys[lvl].notna(), lvl, pd.NA)
    possible_keys_lst = []
    for lvl in lvls_to_explore:
        possible_keys_lst.append(possible_keys[lvl].dropna().unique())
    possible_keys_lst = [item for sublist in possible_keys_lst for item in sublist]
    for key in possible_keys_lst:
        filter_string = key + "!= '' & "
        filter_string = filter_string[0:-3]
        empty_cols = [lvl for lvl in lvls_to_explore if lvl not in key]
        cols_to_drop = []
        for col in fixed_coeff_full.columns:
            if col in empty_cols:
                cols_to_drop.append(col)
        fixed_coeff_curr = fixed_coeff_full.drop(columns=cols_to_drop)
        fixed_coeff_curr = fixed_coeff_curr.query(filter_string)
        fixed_coeff_curr_t = pd.pivot_table(
            fixed_coeff_curr, index=key, columns="effect", values="estimate"
        ).reset_index()
        pairs_results = pairs_results.merge(fixed_coeff_curr_t, on=[key], how="outer")

    return pairs_results


# %% [markdown]
# ### Function to prepare other fixed effects


# %%
def get_other_fixed_effects(
    fixed_coeff_full: pd.DataFrame, lvl1: str, lvl2: str, lvl3: str
) -> pd.DataFrame:
    """
    Function to prepare other fixed effects (not on level) from full fixed effects df
    Args:
        fixed_coeff_full: fixed effects from modeling
        lvl1: level of aggregation from params
        lvl2: level of aggregation from params
        lvl3: level of aggregation from params
    Returns:
        fixed_coeff_other: other fixed effects
    """
    fixed_coeff_other = pd.DataFrame()
    fixed_coeff_full = fixed_coeff_full.fillna("")

    if lvl3:
        if all(elem in fixed_coeff_full.columns for elem in [lvl1, lvl2, lvl3]):
            fixed_coeff_other = fixed_coeff_full[
                (fixed_coeff_full[lvl1] == "")
                & (fixed_coeff_full[lvl2] == "")
                & (fixed_coeff_full[lvl3] == "")
            ]
        elif all(elem in fixed_coeff_full.columns for elem in [lvl1, lvl2]):
            fixed_coeff_other = fixed_coeff_full[
                (fixed_coeff_full[lvl1] == "") & (fixed_coeff_full[lvl2] == "")
            ]
        elif all(elem in fixed_coeff_full.columns for elem in [lvl1, lvl3]):
            fixed_coeff_other = fixed_coeff_full[
                (fixed_coeff_full[lvl1] == "") & (fixed_coeff_full[lvl3] == "")
            ]
        elif all(elem in fixed_coeff_full.columns for elem in [lvl3, lvl2]):
            fixed_coeff_other = fixed_coeff_full[
                (fixed_coeff_full[lvl2] == "") & (fixed_coeff_full[lvl3] == "")
            ]
    else:
        if all(elem in fixed_coeff_full.columns for elem in [lvl1, lvl2]):
            fixed_coeff_other = fixed_coeff_full[
                (fixed_coeff_full[lvl1] == "") & (fixed_coeff_full[lvl2] == "")
            ]
        elif lvl1 in fixed_coeff_full.columns:
            fixed_coeff_other = fixed_coeff_full[(fixed_coeff_full[lvl1] == "")]
        elif lvl2 in fixed_coeff_full.columns:
            fixed_coeff_other = fixed_coeff_full[(fixed_coeff_full[lvl2] == "")]

    if len(fixed_coeff_other) > 0:
        fixed_coeff_other = pd.pivot_table(
            fixed_coeff_other, columns="effect", values="estimate"
        ).reset_index(drop=True)
    return fixed_coeff_other


# %% [markdown]
# ### Function to merge pairwise results and random effects


# %%
def merge_random_effect(
    pairs_results: pd.DataFrame,
    rand_eff_transpose: pd.DataFrame,
    lvl1: str,
    lvl2: str,
    lvl3: str,
) -> pd.DataFrame:
    """
    Function to merge pairwise results and random effects
    Args:
        pairs_results: pairwise results
        rand_eff_transpose: transposed random effects
        lvl1: level of aggregation from params
        lvl2: level of aggregation from params
        lvl3: level of aggregation from params
    Returns:
        pairs_results: pairwise results with random effects
    """
    pairs_results = pairs_results.merge(
        rand_eff_transpose, on=list(filter(None, [lvl1] + [lvl2] + [lvl3])), how="outer"
    )
    pairs_results.columns = pairs_results.columns.str.replace("*", "_", regex=False)
    return pairs_results


# %% [markdown]
# ### Function to merge pairwise results and other fixed effects


# %%
def merge_other_effect(
    pairs_results: pd.DataFrame, fixed_coeff_other: pd.DataFrame
) -> pd.DataFrame:
    """
    Function to merge pairwise results and other fixed effects
    Args:
        pairs_results: pairwise results
        fixed_coeff_other: transposed other fixed effects
    Returns:
        df: pairwise results with random effects
    """
    if len(fixed_coeff_other) > 0:
        fixed_coeff_other["key"] = 1
        pairs_results["key"] = 1
        pairs_results = pairs_results.merge(
            fixed_coeff_other, on=["key"], how="outer"
        ).drop(columns=["key"])
    # replace NAs with 0
    numeric_columns = pairs_results.select_dtypes(include=["number"]).columns
    pairs_results[numeric_columns] = pairs_results[numeric_columns].fillna(0)
    return pairs_results


# %% [markdown]
# ### Function to calculate error on the results dataframe


# %%
def calculate_error(
    results: pd.DataFrame, unit_approach_flag: str, actual_units: str, volume: str
) -> pd.DataFrame:
    """
    Function to calculate errors on results dataframe
    Args:
        results: results dataframe from modeling
        unit_approach_flag: unit approach flag from params
        actual_units: actual units column from params
        volume: volume column from params
    Returns:
        results: results dataframe with error columns calculated
    """
    if unit_approach_flag:
        results["predicted_units"] = np.exp(results["pred"])
        results["error"] = results[actual_units] - results["predicted_units"]
        results["pct_error"] = (
            results[actual_units] - results["predicted_units"]
        ) / results[actual_units]
    else:
        results["predicted_vol"] = np.exp(results["pred"])
        results["error"] = results[volume] - results["predicted_vol"]
        results["pct_error"] = (results[volume] - results["predicted_vol"]) / results[
            volume
        ]
    results["abs_pct_error"] = np.abs(results["pct_error"])
    return results


# %% [markdown]
# ### Function to calculate statistics


# %%
def calculate_statistics(
    pairs_results: pd.DataFrame,
    results: pd.DataFrame,
    unit_approach_flag: bool,
    actual_units: str,
    volume: str,
    lvl1: str,
    lvl2: str,
    lvl3: str,
) -> pd.DataFrame:
    """
    Function to calculate fit statistics and merge to pairwise results
    Args:
        pairs_results: pairwise results dataframe
        results: results dataframe with errors calculated
        unit_approach_flag: unit approach flag from params
        actual_units: actual units column from params
        volume: volume column from params
        lvl1: level of aggregation from params
        lvl2: level of aggregation from params
        lvl3: level of aggregation from params
    Returns:
        pairs_results: pairwise results dataframe with fit statistics
    """
    results_g = results.copy()
    if unit_approach_flag:

        results_g["sq_err"] = (
            results_g[actual_units] - results_g["predicted_units"]
        ) ** 2
        results_g["ts"] = (results_g[actual_units] - results_g["avg_actual_units"]) ** 2
        results_g = (
            results_g.groupby(
                by=list(filter(None, [lvl1] + [lvl2] + [lvl3])), observed=True
            )
            .agg(
                mpe=("pct_error", "mean"),
                predicted_units=("predicted_units", "sum"),
                rss=("sq_err", "sum"),
                tss=("ts", "sum"),
                mape=("abs_pct_error", "mean"),
            )
            .reset_index()
        )
    else:
        results_g["sq_err"] = (results_g[volume] - results_g["predicted_vol"]) ** 2
        results_g["ts"] = (results_g[volume] - results_g["avg_volume"]) ** 2
        results_g = (
            results_g.groupby(
                by=list(filter(None, [lvl1] + [lvl2] + [lvl3])), observed=True
            )
            .agg(
                mpe=("pct_error", "mean"),
                predicted_volume=("predicted_vol", "sum"),
                rss=("sq_err", "sum"),
                tss=("ts", "sum"),
                mape=("abs_pct_error", "mean"),
            )
            .reset_index()
        )
    pairs_results = pairs_results.merge(
        results_g, on=list(filter(None, [lvl1] + [lvl2] + [lvl3])), how="outer"
    )
    pairs_results["rsq"] = 1 - (pairs_results["rss"] / pairs_results["tss"])
    return pairs_results


# %% [markdown]
# ### Function to calculate elasticities


# %%
def calculate_elasticities(
    pairs_results: pd.DataFrame, unit_approach_flag: bool, price: str, weight_flag: str
) -> pd.DataFrame:
    """
    Function to calculate fit statistics and merge to pairwise results
    Args:
        pairs_results: pairwise results dataframe
        unit_approach_flag: unit approach flag from params
        price: price column
        weight_flag: weight column
    Returns:
        pairs_results: pairwise results dataframe with fit statistics
    """
    cols_for_elast = pairs_results.columns[
        pairs_results.columns.str.match(f"([fr]e_.*{price})")
    ]
    pairs_results["elasticity"] = pairs_results[cols_for_elast].sum(axis=1)
    if unit_approach_flag:
        # Calculate weight elasticity
        cols_for_welast = pairs_results.columns[
            pairs_results.columns.str.match(f"([fr]e_.*{weight_flag})")
        ]
        pairs_results["weight_elasticity"] = pairs_results[cols_for_welast].sum(axis=1)
    return pairs_results


# %% [markdown]
# ### Function to create column with flag indicating robust results


# %%
def create_flag(
    pairs_results: pd.DataFrame,
    elasticity_filter_range: list,
    mape_crit_for_flag: float,
    rsq_crit_for_flag: float,
) -> pd.DataFrame:
    """
    Function to create column with flag indicating robust results
    Args:
        pairs_results: pairwise results dataframe
        elasticity_filter_range: range of acceptable elasticities from params
        mape_crit_for_flag: critical value for mape from params
        rsq_crit_for_flag: critical value for rsq from params
    Returns:
        pairs_results: pairwise results dataframe with fit statistics
    """
    pairs_results["flag_str"] = np.where(
        (
            pairs_results["elasticity"].between(
                elasticity_filter_range[0], elasticity_filter_range[1]
            )
        )
        & (pairs_results["mape"] < mape_crit_for_flag)
        & (pairs_results["rsq"] > rsq_crit_for_flag),
        "GOOD",
        "DROP",
    )
    return pairs_results


# %% [markdown]
# ### create_results function


# %%
def create_results(
    random_dt: pd.DataFrame,
    mod_data: pd.DataFrame,
    results: pd.DataFrame,
    fixed_coeff_full: pd.DataFrame,
    fixed_effect: pd.DataFrame,
    parameters: dict,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Master function to create modeling summaries
    Args:
        random_dt: random effects dataframe from modeling
        mod_data: modeling data
        results: model results dataframe
        fixed_coeff_full: fixed effects dataframe from modeling
        fixed_effect: fixed effect part of modeling equation string
        parameters: parameters dictionary
    Returns:
        pairs_results: pairwise results dataframe with fit statistics
        results: results dataframe with error columns
    """
    lvl1 = parameters["ewb"]["data_management"]["levels"]["lvl1"]
    lvl2 = parameters["ewb"]["data_management"]["levels"]["lvl2"]
    lvl3 = parameters["ewb"]["data_management"]["levels"]["lvl3"]
    value = parameters["ewb"]["data_management"]["value"]
    volume = parameters["ewb"]["data_management"]["volume"]
    price = parameters["ewb"]["data_management"]["price_col"]

    unit_approach_flag = False
    actual_units = None
    weight_flag = None

    elasticity_filter_range = parameters["ewb"]["modeling"]["quality"][
        "elasticity_filter_range"
    ]
    mape_crit_for_flag = parameters["ewb"]["modeling"]["quality"]["mape_crit_for_flag"]
    rsq_crit_for_flag = parameters["ewb"]["modeling"]["quality"]["rsq_crit_for_flag"]

    rand_eff_transpose = prepare_random_effect(random_dt, lvl1, lvl2, lvl3)
    fixed_coeff_full = prepare_fixed_effect(fixed_coeff_full)
    pairs_results = merge_pairs_to_fixed(
        fixed_coeff_full,
        mod_data,
        fixed_effect,
        unit_approach_flag,
        value,
        volume,
        price,
        actual_units,
        lvl1,
        lvl2,
        lvl3,
    )
    fixed_coeff_other = get_other_fixed_effects(fixed_coeff_full, lvl1, lvl2, lvl3)
    pairs_results = merge_random_effect(
        pairs_results, rand_eff_transpose, lvl1, lvl2, lvl3
    )
    pairs_results = merge_other_effect(pairs_results, fixed_coeff_other)
    results = calculate_error(results, unit_approach_flag, actual_units, volume)
    pairs_results = calculate_statistics(
        pairs_results,
        results,
        unit_approach_flag,
        actual_units,
        volume,
        lvl1,
        lvl2,
        lvl3,
    )
    pairs_results = calculate_elasticities(
        pairs_results, unit_approach_flag, price, weight_flag
    )
    pairs_results = create_flag(
        pairs_results, elasticity_filter_range, mape_crit_for_flag, rsq_crit_for_flag
    )
    return pairs_results, results


# %% [markdown]
# ## Master function to run mixed models

# %%
data = base_loess
level_1 = params["ewb"]["data_management"]["levels"]["lvl1"]
level_2 = params["ewb"]["data_management"]["levels"]["lvl2"]
level_3 = params["ewb"]["data_management"]["levels"]["lvl3"]
volume = params["ewb"]["data_management"]["volume"]
seasonality = params["ewb"]["modeling"]["common"]["seasonality_term"]

print("Starting data prep for mixed modeling")

grouping_columns = list(filter(None, [level_1] + [level_2] + [level_3]))

# filtering only good pairs
data_trimmed = data[data["general_flag"] == "GOOD"].reset_index(drop=True)
# Summing volume by the levels and adding to main dataset
data_trimmed["vol_total"] = data_trimmed.groupby(grouping_columns)[volume].transform(
    "sum"
)
data_trimmed.to_csv("01_intermediate_outputs/own/mod_data.csv", index=False)
print("done")

# %%
from termcolor import colored


# %%
def run_mixed_models(
    base_loess: pd.DataFrame,
    params: dict,
    # catalog: dict, ### No catalog in notebook
    re_structured,
    re_structured_cpi,
    re_unstructured,
    re_unstructured_cpi,
    pl_list,
) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    Dict,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    """
    Master function to run mixed model functions
    Args:
        base_loess: output dataframe from loess
        params: parameters dictionary
        catalog : catalog dictionary (Not using in notebook)
        re_structured
        re_structured_cpi
        re_unstructured
        re_unstructured_cpi
    Returns:
        s1 : dataframe of model results for structured without cpi
        s2 : dataframe of model results for structured with cpi
        u1 : dataframe of model results for unstructured without cpi
        u2 : dataframe of model results for unstructured with cpi
        fe_dict : fixed effects formula dictionary
    """
    print("started running mix model")
    # modeling params
    fe_structured = params["ewb"]["modeling"]["mixed_models"]["fe_structured"]
    fe_structured_cpi = params["ewb"]["modeling"]["mixed_models"]["fe_structured_cpi"]
    fe_unstructured = params["ewb"]["modeling"]["mixed_models"]["fe_unstructured"]
    fe_unstructured_cpi = params["ewb"]["modeling"]["mixed_models"][
        "fe_unstructured_cpi"
    ]

    # pl variable
    pl_list_len = str(len(pl_list))

    # data and formula prep for mixed modeling
    print(colored("preparing data for MM", "yellow"))
    data_to_fit, mod_data = prep_data_for_MM(base_loess, params)

    ### direclty loading the data ###########################
    # print('loading data_to_fit, mod_data')
    # data_to_fit = pd.read_csv("01_intermediate_outputs/data_to_fit.csv")
    # mod_data = pd.read_csv("01_intermediate_outputs/own/mod_data.csv")
    # data_to_fit = ("/Users/manas/Desktop/Sigmoid Work/Reckitt/01_rgmx-econometrics-US_SurfaceCare/01_intermediate_outputs/data_to_fit.csv")
    #########################################################

    # creating a dictionary to store all the fixed_effects formulae for the 4 models
    fe_dict = {}

    # Run structured model without CPI
    print("Building the structured model without CPI")
    results, fixed_dt, random_dt, fe = fit_and_predict(
        data_to_fit, params, fe_structured, re_structured
    )

    s1, s1_res = create_results(random_dt, mod_data, results, fixed_dt, fe, params)
    # write_obj(
    #     s1,
    #     catalog["model_results_struct_without_cpi"]["filepath"],
    #     catalog["model_results_struct_without_cpi"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["model_results_struct_without_cpi"]["format"],
    # )
    ### saving the results for structured model without cpi
    print(colored("saving s1"), "green")
    s1.to_csv(
        "./04_model_results/model_results/own/model_results_struct_without_cpi.csv",
        index=False,
    )

    # write_obj(
    #     s1_res,
    #     catalog["full_results_struct_without_cpi"]["filepath"],
    #     catalog["full_results_struct_without_cpi"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["full_results_struct_without_cpi"]["format"],
    # )
    print(colored("saving s1 result"), "green")
    s1_res.to_csv(
        "./04_model_results/model_results/own/full_model_results_struct_without_cpi.csv",
        index=False,
    )
    fe_dict["fe_struct_without_cpi"] = fe

    # Run structured model with CPI
    print(colored("Building the structured model with CPI"), "yellow")
    results, fixed_dt, random_dt, fe = fit_and_predict(
        data_to_fit, params, fe_structured_cpi, re_structured_cpi
    )
    s2, s2_res = create_results(random_dt, mod_data, results, fixed_dt, fe, params)
    print(colored("saving s2 and s2 res"), "green")
    s2.to_csv(
        "./04_model_results/model_results/own/model_results_struct_with_cpi.csv",
        index=False,
    )
    s2_res.to_csv(
        "./04_model_results/model_results/own/full_model_results_struct_with_cpi.csv",
        index=False,
    )
    fe_dict["fe_struct_with_cpi"] = fe

    # Run unstructured model without CPI
    print(colored("Building the unstructured model without CPI"), "yellow")
    results, fixed_dt, random_dt, fe = fit_and_predict(
        data_to_fit, params, fe_unstructured, re_unstructured
    )
    u1, u1_res = create_results(random_dt, mod_data, results, fixed_dt, fe, params)
    print(colored("created result for u1 and u1_res"), "green")
    u1.to_csv(
        "./04_model_results/model_results/own/model_results_unstruct_without_cpi.csv",
        index=False,
    )
    u1_res.to_csv(
        "./04_model_results/model_results/own/full_model_results_unstruct_without_cpi.csv",
        index=False,
    )
    fe_dict["fe_unstruct_without_cpi"] = fe

    # Run unstructured model wit CPI
    print(colored("Building the unstructured model with CPI"), "yellow")
    results, fixed_dt, random_dt, fe = fit_and_predict(
        data_to_fit, params, fe_unstructured_cpi, re_unstructured_cpi
    )
    u2, u2_res = create_results(random_dt, mod_data, results, fixed_dt, fe, params)
    print(colored("created result for u2 and u2_res"), "green")
    u2.to_csv(
        "./04_model_results/model_results/own/model_results_unstruct_with_cpi.csv",
        index=False,
    )
    u2_res.to_csv(
        "./04_model_results/model_results/own/full_model_results_unstruct_with_cpi.csv",
        index=False,
    )
    fe_dict["fe_unstruct_with_cpi"] = fe

    # save fixed effects dictionary
    file_path = (
        "./01_intermediate_outputs/own/fixed_effects" + f"_pl{pl_list_len}" + ".txt"
    )
    with open(file_path, "w") as file:
        file.write(json.dumps(fe))

    return s1, s2, u1, u2, fe_dict, s1_res, s2_res, u1_res, u2_res


# %% [markdown]
# # Testing julia

# %%
# from julia import Julia
# jl = Julia(compiled_modules=False)
# # Main.fm = fm
# mixed_model_fn = jl.include("//Users/manas/Desktop/Sigmoid Work/Reckitt/RGM Econ/models/mixed_models.jl")

# %% [markdown]
# # Calling the run_mixed_models funciton from mixed_models.py file in automated_pl_run function

# %%
start = pd.Timestamp.now()
print("code started")
s1, s2, u1, u2, fe_dict, s1_res, s2_res, u1_res, u2_res = run_mixed_models(
    base_loess,
    params,
    # catalog,
    re_structured_new,
    re_structured_cpi_new,
    re_unstructured_new,
    re_unstructured_cpi_new,
    pantry_loading,
)
duration = pd.Timestamp.now() - start
print("code run duration:", duration)


# %% [markdown]
# # Consolidating model results for all the data

# %%
from pandas import DataFrame, Series

# %%
# print("Consolidating model results for all data")
# consolidate_model_results(
#             s1,
#             s2,
#             u1,
#             u2,
#             raw_loess_all,
#             params,
#             fe_dict,
#             # catalog,
#             vars_add_logic_new,
#             pantry_loading,
#         )

# %% [markdown]
# ## Function to get four list of columns names across the 4 datasets


# %%
def get_colnames(
    s1: DataFrame, s2: DataFrame, u1: DataFrame, u2: DataFrame
) -> Tuple[List[str], List[str], List[str], List[str], List[str]]:
    """
    Returns four list of columns names across 4 datasets used for various downstream processing

    Args:
        s1 dataframe object, results of running structured mixed model without CPI.
        s2 dataframe object, results of running structured mixed model with CPI.
        u1 dataframe object, results of running unstructured mixed model without CPI.
        u2 dataframe object, results of running unstructured mixed model with CPI.
    Returns:
        all_coeffs: all coefficient across the 4 datasets
        common_coeffs: common coefficient across the 4 datasets
        diff: coefficient that are in all coeffs but not in common coeffs list
        all_vars : all coeffs plus list of other coeffs used in downstream processing
        common_var: common coeffs + other factors used for downstream processing

    """

    all_coefs_s1 = [i for i in s1.columns if i.startswith("fe_")] + [
        i for i in s1.columns if i.startswith("re_")
    ]

    all_coefs_s2 = [i for i in s2.columns if i.startswith("fe_")] + [
        i for i in s2.columns if i.startswith("re_")
    ]

    all_coefs_u1 = [i for i in u1.columns if i.startswith("fe_")] + [
        i for i in u1.columns if i.startswith("re_")
    ]

    all_coefs_u2 = [i for i in u2.columns if i.startswith("fe_")] + [
        i for i in u2.columns if i.startswith("re_")
    ]

    all_coeffs = all_coefs_s1 + all_coefs_s2 + all_coefs_u1 + all_coefs_u2

    all_coeffs = list(set(all_coeffs))

    common_coeffs = list(
        set.intersection(
            *map(
                set,
                [
                    all_coefs_s1,
                    all_coefs_s2,
                    all_coefs_u1,
                    all_coefs_u2,
                ],
            )
        )
    )

    diff = [i for i in all_coeffs if i not in common_coeffs]
    all_vars = [
        "mape",
        "rsq",
        "elasticity",
    ] + all_coeffs
    common_var = [
        "mape",
        "rsq",
        "elasticity",
    ] + common_coeffs

    return (all_coeffs, common_coeffs, diff, all_vars, common_var)


# %%
[col_name for col_name in s1.columns if "fe_month" in col_name]

# %% [markdown]
# ## Function to rename columns


# %%
def rename_columns(df: DataFrame, var_list, prefix) -> DataFrame:
    """
    Returns dataframe with colum names renamed with the prefix_argument

    Args:
        df: Data output from the data preparation step
        var_list : list of column names to be prefixed
        prefix: prefix_names to be used
    Returns:
        df_renamed: Column names with prefix added
    """

    remove_list = ("mpe", "rss", "tss", "flag", "predicted_")

    df_cols = df.columns

    df.columns = [(prefix + "_" + x) if x in var_list else x for x in df_cols]

    df_renamed = df[[i for i in df.columns if not i.startswith(remove_list)]]

    return df_renamed


# %% [markdown]
# ## Function to get merge keys across the 4 datasets


# %%
def find_merge_keys(
    s1: DataFrame, s2: DataFrame, u1: DataFrame, u2: DataFrame
) -> List[str]:
    """
    Returns merge keys across the 4 datasets
    Args:
        s1 dataframe object, results of running structured mixed model without CPI.
        s2 dataframe object, results of running structured mixed model with CPI.
        u1 dataframe object, results of running unstructured mixed model without CPI.
        u2 dataframe object, results of running unstructured mixed model with CPI.
    Returns:
        merge_keys: common coefficient across the 4 datasets
    """

    merge_keys = list(
        set.intersection(
            *map(
                set,
                [
                    s1.columns,
                    s2.columns,
                    u1.columns,
                    u2.columns,
                ],
            )
        )
    )

    return merge_keys


# %% [markdown]
# ## Function to get dataframe with flags based on mape, elasticity and rsq columns


# %%
def flag_performance(df: DataFrame, params: Dict, prefix: str) -> DataFrame:
    """
    Returns dataframe with flags created based on mape, elasticity and rsq columns and thier criteria in params file

    Args:
        df: Data output from the data preparation step
        params : parameter dictionary
        prefix: prefix_names to be used
    Returns:
        df_renamed: Column names with flags added

    """
    mape_crit_for_flag = params["ewb"]["modeling"]["quality"]["mape_crit_for_flag"]
    rsq_crit_for_flag = params["ewb"]["modeling"]["quality"]["rsq_crit_for_flag"]
    elasticity_lower_bound = params["ewb"]["modeling"]["quality"][
        "elasticity_filter_range"
    ][0]
    elasticity_upper_bound = params["ewb"]["modeling"]["quality"][
        "elasticity_filter_range"
    ][1]

    df[prefix + "_mape_flag"] = np.where(
        df[prefix + "_mape"] <= mape_crit_for_flag, True, False
    )

    df[prefix + "_rsq_flag"] = np.where(
        df[prefix + "_rsq"] >= rsq_crit_for_flag, True, False
    )

    df[prefix + "_elasticity_flag"] = np.where(
        (df[prefix + "_elasticity"] >= elasticity_lower_bound)
        & (df[prefix + "_elasticity"] <= elasticity_upper_bound),
        True,
        False,
    )

    df[prefix + "_all_flag"] = np.where(
        (df[prefix + "_elasticity_flag"] == False)
        | (df[prefix + "_rsq_flag"] == False)
        | (df[prefix + "_mape_flag"] == False),
        False,
        True,
    )

    return df


# %% [markdown]
# ## Function to find model


# %%
def find_model(df: DataFrame, model_priority: List[str]) -> str:
    if df[model_priority[0] + "_all_flag"]:
        return model_priority[0]
    elif df[model_priority[1] + "_all_flag"]:
        return model_priority[1]
    elif df[model_priority[2] + "_all_flag"]:
        return model_priority[2]
    elif df[model_priority[3] + "_all_flag"]:
        return model_priority[3]
    else:
        return np.nan


# %% [markdown]
# ## Function to guard rail the pantry loading coefficients


# %%
def check_condition_min(df: DataFrame, var: str, min, max):
    if var in df.index:
        res = (df[var] >= min) & (df[var] < max)
    else:
        res = False
    return res


# %%
def guardrail_pl_coefficients(df, quantile):
    """
    This function guard rails the pantry loading coefficients between the defined quantile value of each column and 0
    Args:
        df: pandas dataframe with consolidated results
        quantile
    """
    start = pd.Timestamp.now()
    # get pl coefficient columns
    pl_cols = [i for i in df.columns if "_re_pl" in i]

    # guardrail the coeffs to be, 0 and greater than quantile value
    for col in pl_cols:
        lower_bound = df[col].quantile(quantile)
        upper_bound = 0
        df["intermediate_" + col] = df.apply(
            lambda x: check_condition_min(x, col, lower_bound, upper_bound), axis=1
        )
        df[col] = np.where(df["intermediate_" + col], df[col], np.nan)
        # df["guardrailed_" + col] = np.where(df["intermediate_" + col], df[col], np.nan)
        df.drop(columns=["intermediate_" + col], inplace=True)

    # # rename the guardrailed cols to actual pl cols and add prefix to the actual pl cols with "actual_"
    # all_pl_cols = [i for i in df.columns if "_re_pl" in i]
    # guardrailed_pl_cols = [i for i in all_pl_cols if "guardrailed_" in i]
    # # non_guardrailed_pl_cols = [i for i in all_pl_cols if "guardrailed_" not in i]
    # # df.columns = [f'before_guardrail_{i}' if i in non_guardrailed_pl_cols else f'{i}' for i in df.columns ]
    # df.columns = [
    #     col.replace("guardrailed_", "") if col in guardrailed_pl_cols else col for col in df.columns
    # ]

    duration = pd.Timestamp.now() - start
    print(f"pl coefficients guardrailed {duration}s")

    return df


# %% [markdown]
# ## Function to create dataframe with the vars adjustment between min/max

# %% [markdown]
# ### Helper functions


# %%
def return_dynamic_col_value_var_1(df: DataFrame, variable_name: str):
    """
    Returns dynamic value by understanding the which model column in df and dynamically selecting the value of the column from which_model_variable_name

    Args:
        df : DataFrame with results
        variable_name: Variable name for which flag is to be created

    Returns:
        val: value based on rules
    """

    if pd.isnull(df.which_model):
        val = np.nan
    else:
        if df.which_model + "_" + variable_name in df.index:
            val = df[df.which_model + "_" + variable_name]
        else:
            val = 0

    return val


# %%
def return_dynamic_col_value_var_2(df: DataFrame, variable_name: str, params: Dict):
    """
    Returns dynamic value by understanding the which model column in df and dynamically selecting the value of the column from which_model_variable_name
    Args:
        df : DataFrame with results
        variable_name : Variable name for which flag is to be created
        params : Parameters dictionary
    Returns:
        val : value based on rules
    """

    model_priority = params["ewb"]["modeling"]["quality"]["model_priority"]

    if pd.isnull(df.which_model):
        val = np.nan
    elif (df.which_model + "_" + variable_name in df.index.tolist()) & (
        df[df.which_model + "_all_flag"] == True
    ):
        val = df[df.which_model + "_" + variable_name]
    elif (model_priority[0] + "_" + variable_name in df.index.tolist()) & (
        df[model_priority[0] + "_all_flag"] == True
    ):
        val = df[model_priority[0] + "_" + variable_name]
    else:
        val = 0

    return val


# %%
def is_inrange_min_incl(df: DataFrame, model_priority: list, var: str, min, max):
    if (pd.isnull(df[var])) | (df[var] > 0):
        if check_condition_min(df, model_priority[0] + "_" + var, min, max):
            val = df[model_priority[0] + "_" + var]
        elif check_condition_min(df, model_priority[1] + "_" + var, min, max):
            val = df[model_priority[1] + "_" + var]
        elif check_condition_min(df, model_priority[2] + "_" + var, min, max):
            val = df[model_priority[2] + "_" + var]
        elif check_condition_min(df, model_priority[3] + "_" + var, min, max):
            val = df[model_priority[3] + "_" + var]
        else:
            val = np.nan
    else:
        val = df[var]
    return val


# %%
def check_condition_max(df: DataFrame, v: str, min, max):
    if v in df.index:
        res = (df[v] > min) & (df[v] <= max)
    else:
        res = False
    return res


# %%
def is_inrange_max_incl(df: DataFrame, model_priority: list, var: str, min, max):
    if (pd.isnull(df[var])) | (df[var] <= 0):
        if check_condition_max(df, model_priority[0] + "_" + var, min, max):
            val = df[model_priority[0] + "_" + var]

        elif check_condition_max(df, model_priority[1] + "_" + var, min, max):
            val = df[model_priority[1] + "_" + var]

        elif check_condition_max(df, model_priority[2] + "_" + var, min, max):
            val = df[model_priority[2] + "_" + var]

        elif check_condition_max(df, model_priority[3] + "_" + var, min, max):
            val = df[model_priority[3] + "_" + var]

        else:
            val = np.nan

    else:
        val = df[var]

    return val


# %% [markdown]
# ### Function add_fe_re


# %%
def add_fe_re(
    df: DataFrame, common_var, diff_var, params: Dict, vars_add_logic: list
) -> DataFrame:
    """
    this function creates dataframe with the vars adjustment between min/max
    Args:
        df : dataframe to which the coefficients are to be processed
        common_var: list of common vars generated in the above step
        diff_var : list of different variables across the 4 models
        params: Dictionary of parameters
    Returns:
        df : dataframe with the vars adjustment between min/max

    """

    model_priority = params["ewb"]["modeling"]["quality"]["model_priority"]
    # vars_add_logic = params["ewb"]["modeling"]["quality"]["vars_add_logic"]
    lvl3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    lvl2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    lvl1 = params["ewb"]["data_management"]["levels"]["lvl1"]

    common_var = common_var + diff_var

    # add common var columns --> fetch it from the best model
    for var in common_var:
        df[var] = df.apply(lambda x: return_dynamic_col_value_var_1(x, var), axis=1)

    # add diff var columns --> fetch it from the best model and cases where the feature is not available in the best model use the hierarchy to pick from next best model
    for var in diff_var:
        df[var] = df.apply(
            lambda x: return_dynamic_col_value_var_2(x, var, params), axis=1
        )

    var_range_1 = [i for i in df.columns if i.startswith("fe_pl")]
    var_range_1 = var_range_1 + [i for i in df.columns if i.startswith("re_pl")]

    var_range_2 = [
        i for i in df.columns if i in ["fe_" + var for var in vars_add_logic]
    ]
    var_range_2 = var_range_2 + [
        i for i in df.columns if i in ["re_" + var for var in vars_add_logic]
    ]
    var_range_2 = [i for i in var_range_2 if i not in var_range_1]

    if len(var_range_1) > 0:
        for var in var_range_1:
            # print(var)
            if len(lvl3) > 0:

                k = (
                    df[
                        [
                            lvl1,
                            lvl2,
                            lvl3,
                        ]
                        + [i for i in df.columns if i.endswith(var)]
                    ]
                    .reset_index()
                    .drop(["index"], axis=1)
                )
                k[var] = k.apply(
                    lambda x: is_inrange_min_incl(x, model_priority, var, -1, 0), axis=1
                )
                df = df[
                    [
                        i
                        for i in df.columns
                        if i not in [i for i in df.columns if i.endswith(var)]
                    ]
                ].merge(k, on=[lvl1, lvl2, lvl3], how="left")
            else:
                k = (
                    df[
                        [
                            lvl1,
                            lvl2,
                        ]
                        + [i for i in df.columns if i.endswith(var)]
                    ]
                    .reset_index()
                    .drop(["index"], axis=1)
                )
                k[var] = k.apply(
                    lambda x: is_inrange_min_incl(x, model_priority, var, -1, 0), axis=1
                )
                df = df[
                    [
                        i
                        for i in df.columns
                        if i not in [i for i in df.columns if i.endswith(var)]
                    ]
                ].merge(k, on=[lvl1, lvl2], how="left")
    if len(var_range_2) > 0:
        for var in var_range_2:
            # print(var)
            if len(lvl3) > 0:

                k = (
                    df[
                        [
                            lvl1,
                            lvl2,
                            lvl3,
                        ]
                        + [i for i in df.columns if i.endswith(var)]
                    ]
                    .reset_index()
                    .drop(["index"], axis=1)
                )

                k[var] = k.apply(
                    lambda x: is_inrange_max_incl(x, model_priority, var, 0, 1), axis=1
                )
                df = df[
                    [
                        i
                        for i in df.columns
                        if i not in [i for i in df.columns if i.endswith(var)]
                    ]
                ].merge(k, on=[lvl1, lvl2, lvl3], how="left")
            else:
                k = (
                    df[
                        [
                            lvl1,
                            lvl2,
                        ]
                        + [i for i in df.columns if i.endswith(var)]
                    ]
                    .reset_index()
                    .drop(["index"], axis=1)
                )
                k[var] = k.apply(
                    lambda x: is_inrange_max_incl(x, model_priority, var, 0, 1), axis=1
                )
                df = df[
                    [
                        i
                        for i in df.columns
                        if i not in [i for i in df.columns if i.endswith(var)]
                    ]
                ].merge(k, on=[lvl1, lvl2], how="left")
    return df


# %% [markdown]
# ## Function to remove columns that start with {model_priority_<f/r>e_ except distribution variable}


# %%
def remove_model_effect_cols(df: DataFrame, distribution_variable: str) -> DataFrame:
    """
    Removes columns that start with {model_priority_<f/r>e_ except distribution variable}
    Args:
        df: Dataframe with mixed model results combined
        distribution_variable: distribution variable names to be kept in the columns
    Returns:
        df_trimmed: Dataframe with column names to be removed
    """

    df_cols = df.columns
    df_cols_trimmed = [i for i in df_cols if not i.startswith("S1_fe_")] + [
        i for i in df_cols if i.startswith("S1_fe_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("S2_fe_")] + [
        i for i in df_cols_trimmed if i.startswith("S2_fe_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("U1_fe_")] + [
        i for i in df_cols_trimmed if i.startswith("U1_fe_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("U2_fe_")] + [
        i for i in df_cols_trimmed if i.startswith("U2_fe_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("S1_re_")] + [
        i for i in df_cols_trimmed if i.startswith("S1_re_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("S2_re_")] + [
        i for i in df_cols_trimmed if i.startswith("S2_re_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("U1_re_")] + [
        i for i in df_cols_trimmed if i.startswith("U1_re_" + distribution_variable)
    ]

    df_cols_trimmed = [i for i in df_cols_trimmed if not i.startswith("U2_re_")] + [
        i for i in df_cols_trimmed if i.startswith("U2_re_" + distribution_variable)
    ]

    df_trimmed = df[df_cols_trimmed]

    return df_trimmed


# %% [markdown]
# ## Function to get modelled or NA flag for the coefficients


# %%
def impute_coeff_flag(x: Series, coeff: str) -> str:
    """
    Returns modelled or NA flag for the coefficients
    Args:
        x : one row of pandas df with all columns
        coeff : coeff to be imputed
    Returns:
        Modeled or nan flag
    """

    if x[coeff] == np.nan:
        return np.nan
    else:
        return "modeled"


# %% [markdown]
# ## Function to find good flag


# %%
def find_good_flag(x):
    """if good flag is in general flag column as one of the flags consider the combination to be good"""

    if x.general_flag.find("GOOD") != -1:
        return "GOOD"
    else:
        return x.general_flag


# %% [markdown]
# ## Master Function to create consolidate results


# %%
def consolidate_model_results(
    s1: DataFrame,
    s2: DataFrame,
    u1: DataFrame,
    u2: DataFrame,
    raw_loess_all: DataFrame,
    params: Dict,
    formula_dict,
    # catalog,
    vars_add_logic,
    pl_list,
) -> pd.DataFrame:
    """
    Returns four list of columns names across 4 datasets used for various downstream processing

    Args:
        s1 : dataframe object, results of running structured mixed model without CPI.
        s2 : dataframe object, results of running structured mixed model with CPI.
        u1 : dataframe object, results of running unstructured mixed model without CPI.
        u2 : dataframe object, results of running unstructured mixed model with CPI.
        raw_loess_all : raw loess data with all the good and bad cases
        params : Dictionary of parameters
        catalog : Dictionary of catalogs

    Returns:
        consolid_res : consolidateed results dataframe

    """
    start = pd.Timestamp.now()

    fixed_effects_structured = formula_dict["fe_struct_without_cpi"]
    fixed_effects_structured_cpi = formula_dict["fe_struct_with_cpi"]
    fixed_effects_unstructured = formula_dict["fe_unstruct_without_cpi"]
    fixed_effects_unstructured_cpi = formula_dict["fe_unstruct_with_cpi"]

    distribution = params["ewb"]["modeling"]["mixed_models"]["distribution"]
    model_priority = params["ewb"]["modeling"]["quality"]["model_priority"]
    price_term = params["ewb"]["modeling"]["common"]["price_term"]
    # covid_factor = params["ewb"]["modeling"]["common"]["covid_factor"]
    elasticity_filter_range = params["ewb"]["modeling"]["quality"][
        "elasticity_filter_range"
    ]
    elasticity_lower_bound = elasticity_filter_range[0]
    elasticity_upper_bound = elasticity_filter_range[1]
    lvl3 = params["ewb"]["data_management"]["levels"]["lvl3"]
    lvl2 = params["ewb"]["data_management"]["levels"]["lvl2"]
    lvl1 = params["ewb"]["data_management"]["levels"]["lvl1"]
    additional_raw_variables = params["ewb"]["data_management"][
        "additional_raw_variables"
    ]
    value = params["ewb"]["data_management"]["value"]
    volume = params["ewb"]["data_management"]["volume"]
    quantile_cutoff = params["ewb"]["modeling"]["quality"]["quantile_cutoff"]

    # pl variable
    pl_list_len = str(len(pl_list))

    all_coeffs, common_coeffs, diff, all_vars, common_vars = get_colnames(
        s1, s2, u1, u2
    )

    s1 = rename_columns(s1, all_vars, "S1")
    s2 = rename_columns(s2, all_vars, "S2")
    u1 = rename_columns(u1, all_vars, "U1")
    u2 = rename_columns(u2, all_vars, "U2")

    merge_keys = find_merge_keys(s1, s2, u1, u2)

    consolid_res = s1.merge(s2, on=merge_keys, how="outer")
    consolid_res = consolid_res.merge(u1, on=merge_keys, how="outer")
    consolid_res = consolid_res.merge(u2, on=merge_keys, how="outer")

    consolid_res = flag_performance(consolid_res, params, "S1")
    consolid_res = flag_performance(consolid_res, params, "S2")
    consolid_res = flag_performance(consolid_res, params, "U1")
    consolid_res = flag_performance(consolid_res, params, "U2")

    consolid_res["any_flag"] = np.where(
        (consolid_res["S1_all_flag"] == False)
        & (consolid_res["S2_all_flag"] == False)
        & (consolid_res["U1_all_flag"] == False)
        & (consolid_res["U2_all_flag"] == False),
        False,
        True,
    )

    consolid_res["which_model"] = consolid_res.apply(
        lambda x: find_model(x, model_priority), axis=1
    )

    # guardrailing pl variables
    consolid_res = guardrail_pl_coefficients(consolid_res, quantile_cutoff)

    df = add_fe_re(consolid_res, common_vars, diff, params, vars_add_logic)

    df_trimmed = remove_model_effect_cols(df, distribution)

    df_trimmed["elasticity"] = np.where(
        (df_trimmed.elasticity >= elasticity_lower_bound)
        & (df_trimmed.elasticity <= elasticity_upper_bound),
        df_trimmed.elasticity,
        np.nan,
    )
    df_trimmed["sumproduct"] = np.where(
        ~(df_trimmed.elasticity.isna()),
        df_trimmed.elasticity * df_trimmed.value,
        np.nan,
    )
    df_cols = df_trimmed.columns
    df_trimmed.columns = [i.replace("loess_4", "trend") for i in df_cols]
    df_trimmed.columns = [i.replace("trend_term", "trend") for i in df_trimmed.columns]
    ############## Commenting covid################
    # df_trimmed.columns = [
    #     i.replace(price_term + "_" + covid_factor, "covid_price_effect") for i in df_trimmed.columns
    # ]

    # concatenate formulas
    fe_list = [
        fixed_effects_structured,
        fixed_effects_structured_cpi,
        fixed_effects_unstructured,
        fixed_effects_unstructured_cpi,
    ]

    # compute list of effect names in the categ_var list
    categ_var = []
    for fe in fe_list:
        categ = get_effect_colnames(fe)
        for item in categ:
            categ_var.append(item)

    impute_list = (
        [i for i in df_trimmed.columns if i.find("re_") != -1]
        + [i for i in df_trimmed.columns if i.find("fe_") != -1]
        + [i for i in df_trimmed.columns if i.find("elasticity") != -1]
    )
    for coeff in impute_list:
        df_trimmed[coeff + "_impute_flag"] = df_trimmed.apply(
            lambda x: impute_coeff_flag(x, coeff), axis=1
        )

    if lvl3 == "":
        flag_df = raw_loess_all[[lvl1, lvl2, "general_flag"]].drop_duplicates()
        aggr_by_flag = (
            flag_df.groupby([lvl1, lvl2])["general_flag"]
            .apply(lambda x: ",".join(x))
            .reset_index()
        )
    else:
        flag_df = raw_loess_all[[lvl1, lvl2, lvl3, "general_flag"]].drop_duplicates()
        aggr_by_flag = (
            raw_loess_all.groupby([lvl1, lvl2, lvl3])["general_flag"]
            .apply(lambda x: ",".join(x))
            .reset_index()
        )

    final_flag = aggr_by_flag

    final_flag["general_flag"] = final_flag.apply(lambda x: find_good_flag(x), axis=1)

    if lvl3 == "":
        # flag_df = raw_loess_all[[lvl1, lvl2, "general_flag"]].drop_duplicates()
        flag_split = (
            raw_loess_all.groupby([lvl1, lvl2])["general_flag"]
            .nunique()
            .reset_index(name="flag_split")
        )
        raw_loess_all = raw_loess_all.merge(flag_split, on=[lvl1, lvl2], how="left")
    else:
        # flag_df = raw_loess_all[[lvl1, lvl2, lvl3, "general_flag"]].drop_duplicates()
        flag_split = (
            raw_loess_all.groupby([lvl1, lvl2, lvl3])["general_flag"]
            .nunique()
            .reset_index(name="flag_split")
        )
        raw_loess_all = raw_loess_all.merge(
            flag_split, on=[lvl1, lvl2, lvl3], how="left"
        )

    mixed_pairs = raw_loess_all[raw_loess_all["flag_split"] != 1][
        additional_raw_variables + [value, volume, "general_flag"]
    ]
    mixed_pairs = (
        mixed_pairs[mixed_pairs["general_flag"] == "GOOD"]
        .groupby(by=additional_raw_variables, dropna=False)[[volume, value]]
        .sum()
        .reset_index()
    )

    mixed_pairs = mixed_pairs.rename(columns={volume: "volume", value: "value"})

    clear_pairs = raw_loess_all[raw_loess_all.flag_split == 1][
        additional_raw_variables + [value, volume, "general_flag"]
    ]
    clear_pairs = (
        clear_pairs.groupby(by=additional_raw_variables, dropna=False)[[volume, value]]
        .sum()
        .reset_index()
    )
    clear_pairs = clear_pairs.rename(columns={volume: "volume", value: "value"})

    additional_var = clear_pairs.append(mixed_pairs)

    if lvl3 == "":
        final_flag = final_flag.merge(additional_var, on=[lvl1, lvl2])
    else:
        final_flag = final_flag.merge(additional_var, on=[lvl1, lvl2, lvl3])

    final_flag = final_flag.drop_duplicates()
    df_trimmed = df_trimmed[
        [i for i in df_trimmed.columns if i not in ["volume", "value"]]
    ]

    merge_var = [i for i in df_trimmed.columns if i in final_flag.columns]
    consolid_res = final_flag.merge(
        df_trimmed[[i for i in df_trimmed.columns if i not in ["volume", "value"]]],
        on=merge_var,
        how="left",
    )

    # Updating a general_flag with "DROP: Non-robust results" for pairs, that don"t meets Rsq and Mape criteria after modelling
    consolid_res["general_flag"] = np.where(
        (consolid_res["general_flag"] == "GOOD") & (consolid_res.any_flag == False),
        "DROP: Non robust results",
        consolid_res["general_flag"],
    )
    consolid_res["general_flag"] = np.where(
        (consolid_res["general_flag"] == "GOOD"),
        "GOOD: Modelled",
        consolid_res["general_flag"],
    )

    duration = pd.Timestamp.now() - start
    print(f"model results consolidated in {duration}s")

    # write_obj(
    #     consolid_res,
    #     catalog["model_consolidated_results"]["filepath"],
    #     catalog["model_consolidated_results"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["model_consolidated_results"]["format"],
    # )
    file_path = (
        "./04_model_results/model_results/model_consolidated_results"
        + f"_pl{pl_list_len}"
        + ".csv"
    )
    consolid_res.to_csv(file_path, index=False)

    return consolid_res


# %% [markdown]
# # Calling the consolidate_model_results function in automated_pl_run

# %%
print("Consolidating model results for all data")
consolidated_df = consolidate_model_results(
    s1,
    s2,
    u1,
    u2,
    raw_loess_all,
    params,
    fe_dict,
    # catalog,
    vars_add_logic_new,
    pantry_loading,
)

# %% [markdown]
# # Imputation

# %% [markdown]
# ## Function to get the coefficients to impute


# %%
def get_coefs_to_impute(df: pd.DataFrame) -> List[str]:
    """
    this function gives us the list of coefficients to be imputed based on regex operation
    Args:
        df : pandas input dataframe
    Returns:
        coef_to_impute: list of coefficients to be imputed
    """

    # list of columns starting with fe_ or re_ or has elasticity in column name
    list1 = df.filter(regex="^fe_|^re_|elasticity", axis=1).columns

    # list of columns starting with S1_elasticity/S2_elasticity/U1_elasticity/U2_elasticity or has _impute_flag in column name
    list2 = df.filter(regex="^(S1|S2|U1|U2)_elasticity|_impute_flag", axis=1).columns

    # get list of coefs to be imputed
    coef_to_impute = list(set(list1) - set(list2))

    return coef_to_impute


# %% [markdown]
# ## Performing the imputation

# %%
import sys
import sklearn.neighbors._base

sys.modules["sklearn.neighbors.base"] = sklearn.neighbors._base
from missingpy import MissForest

import warnings

warnings.filterwarnings("ignore")

# %% [markdown]
# ### Helper function to perfrom imputation

# %% [markdown]
# #### Function to drop list of column from the dataframe inplace


# %%
def df_drop_columns(df: pd.DataFrame, col_list: List[str]) -> pd.DataFrame:
    """
    this function drop list of columns from the dataframe inplace
    Args:
        df : pandas input dataframe
        col_list : list of columns to be dropped

    Returns:
        df : pandas dataframe with columns dropped

    """
    return df.drop(columns=col_list, inplace=True)


# %% [markdown]
# ### Function to impute the coefficients in using the MissForest model


# %%
def impute_coeffs_randomforest(
    df: pd.DataFrame,
    coef_to_impute: List[str],
    imputation_lvl_list: List[str],
    trees: int,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    this function imputes coefficients in using a MissForest model
    Args:
        df : pandas input dataframe
        coef_to_impute : list of coefficients to be imputed
        imputation_lvl_list : level at which imputation is to be done
        trees : #trees argument for MissForest model

    Returns:
        consolidated_results : pandas dataframe with imputed coefficients for all pairs
        consolidated_results_good_pairs : pandas dataframe with imputed coefficients for only good pairs

    """
    start = pd.Timestamp.now()

    # assert if coef_to_impute is only numerical type columns
    try:
        assert set(coef_to_impute).issubset(set(df._get_numeric_data().columns))
        print("All coefficients columns are of type numeric")
    except:
        print(
            "Make sure the coefficient columns to be imputed are numeric as missforest cannot impute categorical variables"
        )

    X = df[coef_to_impute + imputation_lvl_list]
    # perform one hot encoding for categorical variable as Miss forest doesn't support non-numerical
    one_hot = pd.get_dummies(X[imputation_lvl_list])
    X = X.join(one_hot)
    df_drop_columns(X, imputation_lvl_list)

    # fit the miss forest model
    imputer = MissForest(n_estimators=trees, oob_score=True, verbose=0)
    X_imputed = imputer.fit_transform(X)
    X_imputed_df = pd.DataFrame(X_imputed, columns=X.columns)

    # converting the one hot encoded columns back to categorical
    for col in imputation_lvl_list:
        X_imputed_df[col] = (
            X_imputed_df[X_imputed_df.filter(regex=col).columns]
            .idxmax(1)
            .str.replace(col + "_", "")
        )
    df_drop_columns(X_imputed_df, one_hot.columns)

    # add prefix _imp to all the to be imputed coefs
    coef_imputed = [col + "_imp" for col in coef_to_impute]
    dict_coef = {coef_to_impute[i]: coef_imputed[i] for i in range(len(coef_to_impute))}
    X_imputed_df.rename(columns=dict_coef, inplace=True)
    df = pd.concat([df, X_imputed_df], axis=1)

    # impute the coef with Nans
    for coef in coef_to_impute:
        df[coef + "_impute_flag"] = np.where(
            df[coef].isna() == True,
            np.where(
                df[coef + "_imp"].isna() == False, "imputed", df[coef + "_impute_flag"]
            ),
            df[coef + "_impute_flag"],
        )
        df[coef] = np.where(df[coef].isna(), df[coef + "_imp"], df[coef])
        df_drop_columns(df, [coef + "_imp"])

    consolidated_results_good_pairs = df[
        df["general_flag"].isin(["GOOD: Modelled", "DROP: Non robust results"])
    ]
    consolidated_results = df

    duration = pd.Timestamp.now() - start
    print(f"Random Forest coefficient imputation done in {duration}s")

    return consolidated_results, consolidated_results_good_pairs


# %% [markdown]
# ### Function to impute the coefficients in hierarchical manner


# %%
def impute_coeffs_hierarchical(
    df: pd.DataFrame, coef_to_impute: List[str], imputation_lvl_list: List[str]
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    this function imputes coefficients in a hierarchical manner
    Args:
        df : pandas input dataframe
        coef_to_impute : list of coefficients to be imputed
        imputation_lvl_list : hierarchical levels of imputation
    Returns:
        consolidated_results: pandas dataframe with imputed coefficients for all pairs
        consolidated_results_good_pairs : pandas dataframe with imputed coefficients for only good pairs

    """
    start = pd.Timestamp.now()

    for coef in coef_to_impute:
        if df[coef].isna().sum() == 0:
            print("There are no NAs for {} . It will not be imputed.".format(coef))
            continue
        else:
            clean_df = df[df[coef].isna() == False]
            clean_df["product"] = clean_df["value"] * clean_df[coef]
            for lvl in imputation_lvl_list:
                pvt_table = (
                    clean_df.groupby(lvl)[["product", "value", coef]]
                    .sum()
                    .reset_index()
                )
                pvt_table["wtd_" + coef] = pvt_table["product"] / pvt_table["value"]
                df = pd.merge(df, pvt_table[lvl + ["wtd_" + coef]], on=lvl, how="left")
                df[coef + "_impute_flag"] = np.where(
                    df[coef].isna() == True,
                    np.where(
                        df["wtd_" + coef].isna() == False,
                        "imputed",
                        df[coef + "_impute_flag"],
                    ),
                    df[coef + "_impute_flag"],
                )
                df[coef] = np.where(df[coef].isna(), df["wtd_" + coef], df[coef])
                df_drop_columns(df, ["wtd_" + coef])
                if df[coef].isna().sum() == 0:
                    print("no need to go to next level")
                    break

    consolidated_results_good_pairs = df[
        df["general_flag"].isin(["GOOD: Modelled", "DROP: Non robust results"])
    ]
    consolidated_results = df

    duration = pd.Timestamp.now() - start
    print(f"hierarchical coefficient imputation done in {duration}s")

    return consolidated_results, consolidated_results_good_pairs


# %% [markdown]
# ### Master Function to perform the imputation


# %%
def perform_imputation(
    df: pd.DataFrame, params: dict, coef_to_impute: str, pl_list
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    this function chooses between th approach of imputation based on the random_forest_imputation flag
    Args:
        df : pandas input dataframe
        params : parameter dictionary
        coef_to_impute : list of coef to impute
        catalog : dict with catalog of data files

    Returns:
        consolidated_results: pandas dataframe with imputed coefficients for all pairs
        consolidated_results_good_pairs : pandas dataframe with imputed coefficients for only good pairs
    """

    random_forest_imputation_flag = params["ewb"]["modeling"]["post_processing"][
        "random_forest_imputation_flag"
    ]
    imputation_lvl_list = params["ewb"]["modeling"]["post_processing"][
        "imputation_lvl_list"
    ]
    imputation_lvl_list_for_RF = params["ewb"]["modeling"]["post_processing"][
        "imputation_lvl_list_for_RF"
    ]
    trees = params["ewb"]["modeling"]["post_processing"]["trees"]

    # pl variable
    pl_list_len = str(len(pl_list))

    imputation_lvl_list = list(filter(None, imputation_lvl_list))
    imputation_lvl_list_for_RF = list(filter(None, imputation_lvl_list_for_RF))

    if random_forest_imputation_flag:
        consolidated_results, consolidated_results_good_pairs = (
            impute_coeffs_randomforest(
                df, coef_to_impute, imputation_lvl_list_for_RF, trees
            )
        )
    else:
        consolidated_results, consolidated_results_good_pairs = (
            impute_coeffs_hierarchical(df, coef_to_impute, imputation_lvl_list)
        )

    # save outputs
    # write_obj(
    #     consolidated_results,
    #     catalog["consolidated_imputed_all_output"]["filepath"],
    #     catalog["consolidated_imputed_all_output"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["consolidated_imputed_all_output"]["format"],
    # )
    ###
    file_path = (
        "./05_model_post_processing/consolidated_results_pl3"
        + f"_pl{pl_list_len}"
        + ".csv"
    )
    consolidated_results.to_csv(file_path, index=False)

    # write_obj(
    #     consolidated_results_good_pairs,
    #     catalog["consolidated_imputed_good_output"]["filepath"],
    #     catalog["consolidated_imputed_good_output"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["consolidated_imputed_good_output"]["format"],
    # )
    file_path = (
        "./05_model_post_processing/consolidated_results_good_pairs"
        + f"_pl{pl_list_len}"
        + ".csv"
    )
    consolidated_results.to_csv(file_path, index=False)

    return consolidated_results, consolidated_results_good_pairs


# %% [markdown]
# # Calling the imputation functions in automated_pl_run function

# %%
print("Running coefficient imputation code...")
coef_to_impute = get_coefs_to_impute(consolidated_df)
consolidated_results, consolidated_results_good_pairs = perform_imputation(
    consolidated_df, params, coef_to_impute, pantry_loading
)

# %% [markdown]
# # Pantry loading decay


# %%
def pantry_loading_decay(res: pd.DataFrame, pl_list) -> pd.DataFrame:
    """
    Helper function that decays pantry loading coefficients.

    Args:
        res: pd.DataFrame
            Dataset containing general consolidated results.
        catalog : dictionary with catalog entries

    Returns: pd.DataFrame
        Dataset containing general consolidated results with decayed PL coefficients.
    """
    start = pd.Timestamp.now()

    # pl variable
    pl_list_len = str(len(pl_list))

    decayed_pl_cols_list = [
        col for col in res.columns if ("re_pl" in col) & ("impute_flag" not in col)
    ]
    decayed_pl_cols_list.sort()
    for col in decayed_pl_cols_list:
        res[f"bef_decay_{col}"] = res[col]

    bef_decay_pl_cols_list = [f"bef_decay_{i}" for i in decayed_pl_cols_list]
    bef_decay_pl_cols_list.sort()

    for idx, col in enumerate(decayed_pl_cols_list):
        if idx == 0:
            res[col] = res[bef_decay_pl_cols_list[idx]]
        elif idx == 1:
            col_lag_1 = decayed_pl_cols_list[idx - 1]
            res[col] = np.where(
                abs(res[bef_decay_pl_cols_list[idx]]) >= abs(res[col_lag_1]),
                res[col_lag_1],
                res[bef_decay_pl_cols_list[idx]],
            )
        elif idx > 1:
            col_lag_1 = decayed_pl_cols_list[idx - 1]
            col_lag_2 = decayed_pl_cols_list[idx - 2]

            res[col] = np.where(
                abs(res[bef_decay_pl_cols_list[idx]]) >= abs(res[col_lag_1]),
                (res[col_lag_1] / res[col_lag_2]) * res[col_lag_1],
                res[bef_decay_pl_cols_list[idx]],
            )

    # add code to fill nulls with na for all pl columns
    impute_null_pl_cols = [
        col
        for col in res.columns
        if ("re_pl" in col) & ("impute_flag" not in col) & ("_re_pl" not in col)
    ]
    res[impute_null_pl_cols] = res[impute_null_pl_cols].fillna(0)

    duration = pd.Timestamp.now() - start
    print(f"model results consolidated in {duration}s")

    # write_obj(
    #     res,
    #     catalog["decay_consolidated_results"]["filepath"],
    #     catalog["decay_consolidated_results"]["filename"] + f"_pl{pl_list_len}",
    #     catalog["decay_consolidated_results"]["format"],
    # )
    file_path = (
        "./05_model_post_processing/decayed_consolidated_results"
        + f"_pl{pl_list_len}"
        + ".csv"
    )
    res.to_csv(file_path, index=False)

    return res


# %% [markdown]
# # Calling the pantry_loading_decay in automated_pl_run

# %%
print("Running pantry loading decay code...")
consolidated_results = pantry_loading_decay(consolidated_results, pantry_loading)

print("Calculating prediction for OOT period skipped")

print(f"single run complete for {pantry_loading}")

# %%
### return consolidated_results, consolidated_results_good_pairs, s1_res, s2_res, u1_res, u2_res
### We have saved these results in there specific loactions
